#!/usr/bin/env bash

##############################################################################################################
# ScanCode
#
# Detects licenses, copyrights, package manifests & dependencies and more by scanning code
# ... to discover and inventory open source and third-party packages used in your code.
# https://github.com/nexB/scancode-toolkit
#
# This script analyzes all binary applications (EAR/WAR/JAR) in ${APP_DIR_IN} grouped in sub-folders.
##############################################################################################################

# ----- Please adjust
THREADS=10

# ------ Do not modify
VERSION=${SCANCODE_VERSION_DYNAMIC}
STEP=$(get_step)
export LOG_FILE=${REPORTS_DIR}/${STEP}__SCANCODE__${VERSION}.log

# Unpack and delete an archive
function unpack() {
	set +e
	FILE="${1}"
	log_console_info "Unpacking '${FILE}'"
	OUTPUT_DIR="${1%.*}_${1##*.}"
	[[ -d "${OUTPUT_DIR}" ]] && rm -Rf "${OUTPUT_DIR}"
	mkdir -p "${OUTPUT_DIR}"
	UNZIP_OPTS=(-o -P pass "${FILE}" -d "${OUTPUT_DIR}")
	# shellcheck disable=SC2143
	if [[ -n "$(unzip -l "${FILE}" | grep -E ' /$')" ]]; then
		UNZIP_OPTS+=(-x)
		UNZIP_OPTS+=(-/)
	fi
	unzip "${UNZIP_OPTS[@]}" >&6 2>&1
	RC=$?
	if [[ ${RC} -ne 0 ]]; then
		log_console_error "Error while extracting '${FILE}' (${RC})"
		# Remove temporary directory.
		rm -Rf "${OUTPUT_DIR}"
		# Rename the file reflecting the encountered error.
		mv "${FILE}" "${FILE}.${RC}.corrupted"
	fi
	rm -f "${FILE}"
	set -e
}

# Remove dependency to result folder
function cleanup_html() {
	TARGET_FILE=${1}
	DIR_OUT=${2}
	if [ -f "${OUTPUT_FILE}" ]; then
		REGEX="s|${DIR_OUT}/|./|g"
		# Cleaning up 'help.html'
		REGEX2="s|js/jquery.js|jquery.min.js|g"
		REGEX3="s|js/bootstrap.min.js|bootstrap.min.js|g"
		REGEX4='s|class="btn btn-default" id="menu-toggle"|class="btn btn-default"|g'
		if [[ "${IS_MAC}" == "true" ]]; then
			sed -i '' -e "${REGEX}" "${TARGET_FILE}"
			sed -i '' -e "${REGEX2}" "${TARGET_FILE}"
			sed -i '' -e "${REGEX3}" "${TARGET_FILE}"
			sed -i '' -e "${REGEX4}" "${TARGET_FILE}"
		else
			sed -i -e "${REGEX}" "${TARGET_FILE}"
			sed -i -e "${REGEX2}" "${TARGET_FILE}"
			sed -i -e "${REGEX3}" "${TARGET_FILE}"
			sed -i -e "${REGEX4}" "${TARGET_FILE}"
		fi
	fi
}

# Analyse all applications present in the ${1} directory.
function analyze() {
	APP_DIR_INCOMING=${1}
	GROUP=$(basename "${APP_DIR_INCOMING}")
	log_analysis_message "group '${GROUP}'"

	APP_DIR_SRC="${APP_DIR_INCOMING}/src"
	APP_DIR_TMP="${APP_DIR_INCOMING}/tmp"
	APP_DIR_OUT=${REPORTS_DIR}/${STEP}__${GROUP}__SCANCODE__${VERSION}
	OUTPUT_FILE="${APP_DIR_OUT}/index.html"
	HELP_FILE="${APP_DIR_OUT}/index_files/help.html"

	rm -Rf "${APP_DIR_TMP}"
	mkdir -p "${APP_DIR_OUT}" "${APP_DIR_TMP}"
	cp -Rfp "${APP_DIR_SRC}" "${APP_DIR_TMP}"

	while read -r IGNORED_ARCHIVE; do
		NEW_ARCHIVE="${IGNORED_ARCHIVE%.*}"
		mv "${IGNORED_ARCHIVE}" "${NEW_ARCHIVE}"
		unpack "${NEW_ARCHIVE}"
	done < <(find "${APP_DIR_TMP}" -type f -iname '*.ignored_*')

	# Make non-readable files readable.
	find "${APP_DIR_TMP}" ! -perm -o=r -exec chmod +r {} +

	# Remove remaining compiled classes to accelerate the analysis
	find "${APP_DIR_TMP}" -type f -iname '*.class' -delete
	find "${APP_DIR_TMP}" -type f -iname '*.so' -delete

	# Remove cache files to accelerate the analysis
	find "${APP_DIR_TMP}" -type f -regex '^.*/[A-Za-z0-9.]\{32\}\.cache.html$' -delete
	find "${APP_DIR_TMP}" -type f -regex '^.*/gwt-unitCache-[A-Za-z0-9.]\{40\}-[A-Za-z0-9.]\{16\}$' -delete
	find "${APP_DIR_TMP}" -type f -regex '^.*/[A-Za-z0-9.]\{32\}\.symbolMap$' -delete

	log_console_info "Launching ScanCode (${APP_DIR_TMP})"
	set +e
	(time OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES "${SCANCODE}" "${APP_DIR_TMP}/src" -l -p -c --html-app "${OUTPUT_FILE}" --verbose -n "${THREADS}") >>"${LOG_FILE}" 2>&1
	set -e

	# Removing dependency to result folder
	cleanup_html "${OUTPUT_FILE}" "${APP_DIR_OUT}"
	cleanup_html "${HELP_FILE}" "${APP_DIR_OUT}"

	rm -Rf "${APP_DIR_TMP}"

	log_console_success "Open this directory for the results: ${APP_DIR_OUT}/index.html"
}

function main() {

	if [[ "${DEBUG}" == "true" ]]; then
		set -x
		exec 6>&1
	else
		exec 6>/dev/null
	fi

	if [[ -z "$(command -v scancode)" ]]; then
		SCANCODE="${INSTALL_DIR}/scancode-toolkit-${VERSION}/scancode"
	else
		SCANCODE="scancode"
	fi
	for_each_group analyze
}

main
