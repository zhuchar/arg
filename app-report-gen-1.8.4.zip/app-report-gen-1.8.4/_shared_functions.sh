#!/usr/bin/env bash

export GREEN RED ORANGE NC BOLD NORMAL

GREEN='\033[0;32m'
RED='\033[0;31m'
ORANGE='\033[0;33m'
NC='\033[0m' # No Color
BOLD=$(tput bold)
NORMAL=$(tput sgr0)

function log_tool_start() {
	set -u
	echo ">>>>>>> [$(date +%Y_%m_%d__%H_%M_%S)] ${*}" >>"${RUN_LOG}"
	echo -e "${BOLD}>>>>>>> [$(date +%Y_%m_%d__%H_%M_%S)] ${*}${NORMAL}"
}

function log_tool_end() {
	set -u
	echo -e "<<<<<<< [$(date +%Y_%m_%d__%H_%M_%S)] ${*}\n" >>"${RUN_LOG}"
	echo -e "${BOLD}<<<<<<< [$(date +%Y_%m_%d__%H_%M_%S)] ${*}\n${NORMAL}"
}

function log_analysis_message() {
	set -u
	echo " -> Analyzing ${*} ..." | tee -a "${LOG_FILE}"
}

function log_console() {
	echo "${*}" | tee -a "${LOG_FILE}"
}

function log_console_step() {
	log_console " -> ${*}"
}

function log_console_sub_step() {
	log_console "     - ${*}"
}

function log_console_info() {
	log_console "    [INFO] ${*}"
}

function log_console_error() {
	echo "    [ERROR] ${*}" >>"${LOG_FILE}"
	echo -e "${RED}    [ERROR] ${*}${NC}"
}

function log_console_warning() {
	echo "    [WARNING] ${*}" >>"${LOG_FILE}"
	echo -e "${ORANGE}    [WARNING] ${*}${NC}"
}

function log_console_success() {
	echo "    [SUCCESS] ${*}" >>"${LOG_FILE}"
	echo -e "${GREEN}    [SUCCESS] ${*}${NC}"
}

function for_each_group() {
	while read -r DIR; do
		GROUP_NAME="$(basename "${DIR}")"
		if [[ -z "${TARGET_GROUP}" || "${GROUP_NAME}" == "${TARGET_GROUP}" ]]; then
			"${@}" "${DIR}"
		fi
	done < <(find "${APP_DIR_IN}" -maxdepth 1 -mindepth 1 -type d | sort)
}

function get_step() {
	([[ ${0} != "${BASH_SOURCE[0]}" ]] && SCRIPT="${BASH_SOURCE[0]}") || SCRIPT="${0}"
	basename "${SCRIPT}" | cut -d'_' -f1
}

function count_lines() {
	wc -l <"${1}" | tr -d ' '
}
