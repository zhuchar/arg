#!/usr/bin/env bash
# This script extracts results out of the generated PMD reports.

# ----- Please adjust

# ------ Do not modify
SEPARATOR=","
VERSION=${PMD_VERSION}
STEP=$(get_step)
APP_DIR_OUT=${REPORTS_DIR}/${STEP}__PMD__${VERSION}
PMD_DIR_OUT=${APP_DIR_OUT}/pmd
CPD_DIR_OUT=${APP_DIR_OUT}/cpd
export LOG_FILE=${APP_DIR_OUT}.log

function extract() {
	LANGUAGE=${1}
	APP_LIST=${2}
	GROUP=${3}
	RESULT_FILE=${4}

	while read -r APP; do
		APP_NAME=$(basename "${APP}")
		log_analysis_message "app '${APP_NAME}'"

		declare COUNT_VIOLATIONS COUNT_RULES
		if [[ "${LANGUAGE}" == "Java" ]]; then
			#(time "${PMD_RUN}" pmd -dir "${APP}" -cache "${CACHE}" -f summaryhtml -rulesets "${RULESETS}" -failOnViolation false -shortnames >"${PMD_OUT}") >>"${LOG_FILE}" 2>&1
			PMD_FILE=${PMD_DIR_OUT}/${GROUP}__${APP_NAME}_pmd.html
			COUNT_VIOLATIONS=0
			COUNT_RULES=0
			if [[ -f "${PMD_FILE}" ]]; then
				COUNT_VIOLATIONS=$(grep -c '<td align="center">[0-9]*</td>' "${PMD_FILE}" || true)
				COUNT_RULES=$(grep -c '<tr><td>[^<]*</td><td align=center>[0-9]*</td></tr>' "${PMD_FILE}" || true)
			fi
			#echo "${APP_NAME} - LANGUAGE: Java - VIOLATIONS: ${COUNT_VIOLATIONS} - RULES: ${COUNT_RULES}"
		else
			COUNT_VIOLATIONS='n/a'
			COUNT_RULES='n/a'
		fi

		#(time "${PMD_RUN}" cpd --minimum-tokens 100 --files "${APP}" --format xml --language java --failOnViolation false --skip-lexical-errors >"${CPD_OUT}") >>"${LOG_FILE}" 2>&1
		CPD_FILE=${CPD_DIR_OUT}/${GROUP}__${APP_NAME}__cpd.xml

		declare COUNT_DUPLICATED_FRAMENTS TOTAL_DUPLICATED_LINES TOTAL_DUPLICATED_TOKENS
		if [[ -f "${CPD_FILE}" ]]; then
			TOTAL_DUPLICATED_LINES=0
			TOTAL_DUPLICATED_TOKENS=0
			COUNT_DUPLICATED_FRAMENTS=$(grep -c '<duplication lines="' "${CPD_FILE}" || true)
			LINES=0
			TOKENS=0
			FIRST="true"
			while IFS='' read -r LINE; do
				#echo ${LINE}
				if (echo "${LINE}" | grep -q '<duplication lines="'); then
					# shellcheck disable=SC2001
					LINES=$(echo "${LINE}" | sed 's/<duplication lines="\([^"]*\)".*/\1/')
					# shellcheck disable=SC2001
					TOKENS=$(echo "${LINE}" | sed 's/.*tokens="\([^"]*\)">.*/\1/')
					FIRST="true"
					#echo "LINES: $LINES  -  TOKENS: $TOKENS"
				elif (echo "${LINE}" | grep -q '<file [a-z]*="'); then
					if [[ "${FIRST}" == "true" ]]; then
						FIRST="false"
					else
						# Counting duplicates from the second occurence
						TOTAL_DUPLICATED_LINES=$((TOTAL_DUPLICATED_LINES + LINES))
						TOTAL_DUPLICATED_TOKENS=$((TOTAL_DUPLICATED_TOKENS + TOKENS))
						#echo "TOTAL_DUPLICATED_LINES: ${TOTAL_DUPLICATED_LINES}  -  TOTAL_DUPLICATED_TOKENS: ${TOTAL_DUPLICATED_TOKENS}"
					fi
				fi
			done < <(grep '<duplication lines="\|<file [a-z]*="' "${CPD_FILE}")
		else
			COUNT_DUPLICATED_FRAMENTS='n/a'
			TOTAL_DUPLICATED_LINES='n/a'
			TOTAL_DUPLICATED_TOKENS='n/a'
		fi

		#echo "${APP_NAME} - LANGUAGE: Java - DUPLICATED FRAGMENTS: ${COUNT_DUPLICATED_FRAMENTS} - LINES: ${TOTAL_DUPLICATED_LINES} - TOKENS: ${TOTAL_DUPLICATED_TOKENS}"
		echo "${APP_NAME}${SEPARATOR}${LANGUAGE}${SEPARATOR}${COUNT_RULES}${SEPARATOR}${COUNT_VIOLATIONS}${SEPARATOR}${COUNT_DUPLICATED_FRAMENTS}${SEPARATOR}${TOTAL_DUPLICATED_LINES}${SEPARATOR}${TOTAL_DUPLICATED_TOKENS}" >>"${RESULT_FILE}"

	done <"${APP_LIST}"
}

function extract_group() {
	GROUP=$(basename "${1}")
	RESULT_FILE="${APP_DIR_OUT}/${GROUP}___results_extracted.csv"

	if [[ -d "${APP_DIR_OUT}" ]]; then
		rm -f "${RESULT_FILE}"
		touch "${RESULT_FILE}"

		log_analysis_message "group '${GROUP}'"
		extract 'Java' "${REPORTS_DIR}/list__${GROUP}__java-src.txt" "${GROUP}" "${RESULT_FILE}"
		extract 'Python' "${REPORTS_DIR}/list__${GROUP}__python.txt" "${GROUP}" "${RESULT_FILE}"
		extract 'C#' "${REPORTS_DIR}/list__${GROUP}__cs.txt" "${GROUP}" "${RESULT_FILE}"

		# Adding the header
		{
			echo "Applications${SEPARATOR}Language${SEPARATOR}PMD rules triggered${SEPARATOR}PMD violations${SEPARATOR}Copy-pasted fragments${SEPARATOR}Copy-pasted lines${SEPARATOR}Copy-pasted tokens"
			cat "${RESULT_FILE}"
		} >"${RESULT_FILE}.tmp"
		mv "${RESULT_FILE}.tmp" "${RESULT_FILE}"
	else
		LOG_FILE=/dev/null
		log_console_error "PMD result directory does not exist: ${APP_DIR_OUT}"
		exit
	fi
}

function main() {
	for_each_group extract_group
}

main
