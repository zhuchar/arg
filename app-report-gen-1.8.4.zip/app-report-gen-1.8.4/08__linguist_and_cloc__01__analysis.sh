#!/usr/bin/env bash

##############################################################################################################
# GitHub Linguist
#
# Library used on GitHub.com to detect blob languages, ignore binary or vendored files,
# suppress generated files in diffs, and generate language breakdown graphs.
# https://github.com/github/linguist
#
# CLOC - Count Lines of Code
# Counts blank lines, comment lines, and physical lines of source code in many programming languages.
# https://github.com/AlDanial/cloc
#
# This script analyzes all binary applications (EAR/WAR/JAR) in ${APP_DIR_IN} grouped in sub-folders.
##############################################################################################################

# ----- Please adjust

# Ignore files which take more than <CLOC_TIMEOUT> seconds to process. Tool default is 10 seconds.
# Setting <CLOC_TIMEOUT> to 0 allows unlimited time.  (Large files with many repeated lines can cause Algorithm::Diff::sdiff() to take hours.)
CLOC_TIMEOUT=30

# ------ Do not modify
VERSION=${LINGUIST_VERSION}
CLOC=${INSTALL_DIR}/cloc-${CLOC_VERSION}/cloc
STEP=$(get_step)

function linguist() {
	LANG_FILE="${1}"
	REPO="${2}"
	REPO_NAME="${3}"
	LOG_FILE="${4}"
	if [ ! -f "${LANG_FILE}" ]; then
		# Transforms repo in a git repository to avoid linguist to crash.
		if [ ! -d "${REPO}/.git" ]; then
			pushd "${REPO}" &>/dev/null
			set +e
			git init . >/dev/null
			git add -A >/dev/null
			git config user.name "ARG"
			git config user.email "ARG@PIVOTAL.COM"
			git commit -m 'init' >/dev/null
			set -e
			popd &>/dev/null
		fi
		log_console_step "linguist (${REPO_NAME})"
		echo "docker run -t --rm -v \"${REPO}:/repo\" crazymax/linguist:latest > ${LANG_FILE}" >>"${LOG_FILE}"

		set +e
		docker run -t --rm -v "${REPO}:/repo" crazymax/linguist:latest >"${LANG_FILE}" 2>&1 | tee -a "${LOG_FILE}"
		set -e
	fi
}

function analyze_dir() {

	DIR="${1}"
	APP_DIR_SRC="${2}"
	APP_DIR_OUT="${3}"
	GROUP="${4}"
	LOG_FILE="${5}"

	REPO_NAME=$(basename "${DIR}")

	REPO="${APP_DIR_SRC}/${REPO_NAME}"
	LINGUIST_FILE="${APP_DIR_OUT}/${GROUP}__${REPO_NAME}.linguist"
	CLOC_RESULTS="${APP_DIR_OUT}/${GROUP}__${REPO_NAME}.cloc"

	# Run Linguist
	linguist "${LINGUIST_FILE}" "${REPO}" "${REPO_NAME}" "${LOG_FILE}"

	# Run CLOC
	log_console_step "cloc (${REPO_NAME})"

	set +e
	${CLOC} "${DIR}" --csv --diff-timeout "${CLOC_TIMEOUT}" --hide-rate --quiet >"${CLOC_RESULTS}"
	set -e

	# Parsing CLOC results
	PART1=$(grep 'SUM' <"${CLOC_RESULTS}" | awk -F "," -v repo="${REPO_NAME}" -v group="${GROUP}" '{printf("%s;%s;%s;%s;%s;%s", group, repo, $1, $3, $4, $5)}' 2>&1 | tee -a "${LOG_FILE}")
	# Parsing Linguist results
	PART2=$(awk '{printf("%s\t%s\n", $2, $1)}' "${LINGUIST_FILE}" | tr "\r\n\t " ';' | sed -e "s/;;*/;/g" 2>&1 | tee -a "${LOG_FILE}")
	# Parsing CLOC results (bis)
	PART3=$(tail -n +3 <"${CLOC_RESULTS}" | grep -v ",SUM," | awk -F "," '{printf("%s;%s;", $2, $5)}' | awk -F "," -v repo="${REPO_NAME}" -v group="${GROUP}" '{printf("%s;%s;%s", group, repo, $1)}' | tr ' ' '_')

	if [[ ${PART1} == *"${REPO_NAME}"* ]]; then
		echo "${PART1};${PART2}" >>"${OUT_CSV_FILE}"
		echo "${PART3}" >>"${OUT_CLOC_CSV_FILE}"
	fi

}

# Analyse all applications present in the ${1} directory.
function analyze() {

	GROUP=$(basename "${1}")
	APP_DIR_SRC="${1}/src"

	log_analysis_message "group '${GROUP}'"

	while read -r DIR; do
		analyze_dir "${DIR}" "${APP_DIR_SRC}" "${APP_DIR_OUT}" "${GROUP}" "${LOG_FILE}"
	done <"${REPORTS_DIR}/list__${GROUP}__all_apps.txt"

	log_console_success "Results: ${OUT_CSV_FILE}"
}

function main() {

	export APP_DIR_OUT=${REPORTS_DIR}/${STEP}__LINGUIST__${VERSION}
	export LOG_FILE=${APP_DIR_OUT}.log

	# Check if the linguist image is available locally
	if docker images | grep -q 'crazymax/linguist'; then
		log_console_info "Linguist docker image available."
	else
		log_console_info "Importing linguist docker image."
		IMG="${DIST_DIR}/docker__linguist_latest.img"
		set +e
		docker image load -i "${IMG}"
		RC=$?
		set -e
		if [[ ${RC} -ne 0 ]]; then
			log_console_error "Unable to import the docker image in your local registry."
			exit 1
		fi
	fi

	export OUT_CSV_FILE=${APP_DIR_OUT}/../${STEP}__LOC__LINGUIST__results_extracted.csv
	export OUT_CLOC_CSV_FILE=${APP_DIR_OUT}/../${STEP}__LOC__CLOC__results_extracted.csv

	rm -Rf "${APP_DIR_OUT}"
	mkdir -p "${APP_DIR_OUT}"
	rm -f "${OUT_CSV_FILE}" "${OUT_CLOC_CSV_FILE}"

	for_each_group analyze

}

main
