#!/usr/bin/env bash

##############################################################################################################
# Validates several pre-requisites for a seamless analysis:
#  - ulimit set properly
#  - applications copied according to description in README.md
#  - tools distributions present in './dist'
#  - required Java version in use
##############################################################################################################

# ------ Do not modify
NEEDED_ULMIT=100000
NEEDED_JAVA_VERSION=11
NEEDED_MIN_FREE_DISK_SPACE_IN_GB=10
NEEDED_DOTNET_VERSION=3.1

ARE_PREREQUISITES_MET=true
export LOG_FILE=/dev/null

MAX_HARD=$(ulimit -H -n)
MAX_SOFT=$(ulimit -S -n)

if [ "${MAX_SOFT}" == 'unlimited' ]; then MAX_SOFT=${NEEDED_ULMIT}; fi
if [ "${MAX_HARD}" == 'unlimited' ]; then MAX_HARD=${NEEDED_ULMIT}; fi

log_console_step "Check ulimit (>=${NEEDED_ULMIT})"
## Complain if the hard limit is lower than what we need.
if [ ${MAX_SOFT} -lt ${NEEDED_ULMIT} ] || [ ${MAX_HARD} -lt ${NEEDED_ULMIT} ]; then
	if [[ "${IS_MAC}" == "true" ]]; then
		log_console_error "The limits (${MAX_SOFT}/${MAX_HARD}) for open files is too low for running all analysis tools. Please increase them to at least ${NEEDED_ULMIT}.
	[MacOS] Limits are typically configured in '/etc/launchd.conf' or '/etc/sysctl.conf'. To do so, execute this script and -RESTART- your machine: 
	$ ./util/set_ulimit.sh"
	else
		log_console_error "The limits (${MAX_SOFT}/${MAX_HARD}) for open files is too low for running all analysis tools. Please increase them to at least ${NEEDED_ULMIT}.
	[CentOS8/RHEL8] Limits are typically configured in '/etc/security/limits.d/nofile.conf', for example by executing:
	$ sudo echo -e \"*    soft    nofile 100000\n*    hard    nofile 100000\" > /etc/security/limits.d/nofile.conf"
	fi
	ARE_PREREQUISITES_MET=false
else
	log_console_info "ulimit set properly."
fi

mkdir -p "${APP_DIR_IN}"

log_console_step "Check and import present applications (${TARGET_GROUP})"

# Handle "IMPORT_DIR" parameter
SKIP_TARGET_GROUP_ANALYSIS="false"
if [[ -n "${IMPORT_DIR}" ]]; then
	if [[ ! -d "${IMPORT_DIR}" ]]; then
		log_console_error "The specified application import directory ('${IMPORT_DIR}') does not exist."
		ARE_PREREQUISITES_MET=false
		SKIP_TARGET_GROUP_ANALYSIS=true
	else
		if [[ "${IMPORT_DIR}" = "${CURRENT_DIR}"* ]]; then
			log_console_error "The specified application import directory ('${IMPORT_DIR}') must not under the current dir ('${CURRENT_DIR}')."
			ARE_PREREQUISITES_MET=false
			SKIP_TARGET_GROUP_ANALYSIS=true
		else
			rm -Rf "${APP_DIR_IN:?}/${TARGET_GROUP}"
			# Detect if it is a single- or multiple-app directory
			if (find "${IMPORT_DIR}" -mindepth 1 -maxdepth 1 | rev | cut -d '/' -f 1 | rev | grep -q -i -E '^pom.xml$|^readme.md$|^license.md$|^\.git$|^target$|^\.svn$'); then
				log_console_info "Import a single application"
				# Single app in the import directory
				TARGET_DIR="${APP_DIR_IN}/${TARGET_GROUP}/"
			else
				log_console_info "Import multiple applications"
				# Multiple apps in the import directory
				TARGET_DIR="${APP_DIR_IN}/"
			fi
			mkdir -p "${TARGET_DIR}"
			cp -Rfp "${IMPORT_DIR}/../${TARGET_GROUP}" "${TARGET_DIR}."
		fi
	fi
fi

if [[ "${SKIP_TARGET_GROUP_ANALYSIS}" == "false" ]]; then
	if [[ "${TARGET_GROUP}" == "" ]]; then
		# All groups selected
		SELECTED_APP_DIR_IN="${APP_DIR_IN}"
		DEPTH=2
		COUNT_GROUPS=$(find "${APP_DIR_IN}" -maxdepth 1 -mindepth 1 -type d | wc -l | tr -d ' \t')
	else
		# Group selected
		SELECTED_APP_DIR_IN="${APP_DIR_IN}/${TARGET_GROUP}"
		DEPTH=1
		COUNT_GROUPS=1
		if ! find "${APP_DIR_IN}" -maxdepth 1 -mindepth 1 -type d | grep -q "${TARGET_GROUP}"; then
			SELECTED_APP_DIR_IN=""
		fi
	fi
	if [[ -d "${SELECTED_APP_DIR_IN}" ]]; then
		COUNT_SINGLE_APPS=$(find "${SELECTED_APP_DIR_IN}" -maxdepth ${DEPTH} -mindepth ${DEPTH} -type f -name '*.[ejgrhws]ar' -or -name '*.zip' | wc -l | tr -d ' \t')
		COUNT_EXPLODED_APPS=$(find "${SELECTED_APP_DIR_IN}" -maxdepth ${DEPTH} -mindepth ${DEPTH} -type d -not -name 'src' -not -name 'tmp' | wc -l | tr -d ' \t')
		COUNT_APPS=$((COUNT_SINGLE_APPS + COUNT_EXPLODED_APPS))
		if ((COUNT_APPS > 0)); then
			log_console_info "${BOLD}${COUNT_APPS} application(s)${NORMAL} found in ${BOLD}${COUNT_GROUPS} group(s)${NORMAL}."
		else
			log_console_error "No application found. Please organize your applications as described in README.md."
			ARE_PREREQUISITES_MET=false
		fi
	else
		log_console_error "Specified application group ('${TARGET_GROUP}') not found. Please use the import option or organize your applications as described in README.md."
		ARE_PREREQUISITES_MET=false
	fi
fi

# Validating presence of bundled tools
log_console_step "Check tools distributions"
mkdir -p "${DIST_DIR}"
TOOLS=(
	"cloud-suitability-analyzer-${CSA_VERSION}.zip"
	"ibm-wamt-${WAMT_VERSION}.zip"
	"dependency-check-${OWASP_DC_VERSION}-release.zip"
	"fernflower.jar"
	"scancode-toolkit-${SCANCODE_VERSION}.zip"
	"pmd-bin-${PMD_VERSION}.zip"
)
for TOOL in "${TOOLS[@]}"; do
	if [ -f "${DIST_DIR}/${TOOL}" ]; then
		log_console_info "'${TOOL}' present."
	else
		log_console_error "'${TOOL}' is missing! Please add it to '${DIST_DIR}'."
		ARE_PREREQUISITES_MET=false
	fi
done

# Java version validation
log_console_step "Check Java version (=${NEEDED_JAVA_VERSION})"
ERROR_MESSAGE_JAVA_VERSION=''
if [[ -n "$(command -v javac)" ]]; then
	if javac -version 2>&1 | grep -q 'No Java runtime present'; then
		ERROR_MESSAGE_JAVA_VERSION="No Java runtime present. Please install Java ${NEEDED_JAVA_VERSION}."
	else
		JAVA_VERSION=$(javac -version 2>&1 | grep 'javac' | awk '{print $2}')
		JAVA_VERSION_MAJOR="$(echo "${JAVA_VERSION}" 2>&1 | cut -d . -f 1)"
		COUNT_ZULU=$(java -version 2>&1 | grep -c 'Zulu' || true)
		if ((COUNT_ZULU > 0)); then
			ERROR_MESSAGE_JAVA_VERSION="Wrong JDK provider in use ('Zulu'). Please switch to a non-Zulu JDK."
		elif ((JAVA_VERSION_MAJOR != NEEDED_JAVA_VERSION)); then
			ERROR_MESSAGE_JAVA_VERSION="Wrong Java version ('${JAVA_VERSION}') in use. Please switch to Java ${NEEDED_JAVA_VERSION}."
		fi
	fi
else
	ERROR_MESSAGE_JAVA_VERSION="Java is not available. Please install Java ${NEEDED_JAVA_VERSION}."
fi
if [ -z "${ERROR_MESSAGE_JAVA_VERSION}" ]; then
	log_console_info "Compatible Java version ('${JAVA_VERSION}') in use."
else
	ARE_PREREQUISITES_MET=false

	if [[ "${IS_MAC}" == "true" ]]; then
		log_console_error "${ERROR_MESSAGE_JAVA_VERSION}
	[MacOS] Java ${NEEDED_JAVA_VERSION} installation with SDKMAN! (https://sdkman.io/): 
	$ curl -s \"https://get.sdkman.io\" | bash
	$ source ~/.sdkman/bin/sdkman-init.sh
	$ sdk install java 11.0.6.hs-adpt"
	else
		log_console_error "No Java runtime present. Please install Java ${NEEDED_JAVA_VERSION}.
	[CentoOS/RHEL/Fedora] Java ${NEEDED_JAVA_VERSION} installation with yum:
	$ sudo yum -y install java-11-openjdk-devel"
	fi
fi

# Bash version validation
log_console_step "Check Bash version (>=4)"
MAJOR_BASH_VERSION=$(echo "${BASH_VERSION}" | cut -d . -f 1)
if ((MAJOR_BASH_VERSION < 4)); then
	INSTRUCTIONS=''
	if [[ "${IS_MAC}" == "true" ]]; then
		INSTRUCTIONS=" ('$ brew install bash' on MacOS)"
	fi
	log_console_error "You are running Bash '${BASH_VERSION}'. Please update it to version 4 or later.${INSTRUCTIONS}"
	ARE_PREREQUISITES_MET=false
else
	log_console_info "Compatible Bash version ('${BASH_VERSION}') in use."
fi

# Free disk space validation
log_console_step "Check free disk space (>=${NEEDED_MIN_FREE_DISK_SPACE_IN_GB}GB)"
declare AVAILABLE_FREE_GB
if [[ "${IS_MAC}" == "true" ]]; then
	AVAILABLE_FREE_GB=$(df -Pg . | tail -1 | awk '{print $4}')
else
	AVAILABLE_FREE_GB=$(df -BG -P . | tail -1 | awk '{print $4}' | tr -d 'G')
fi
if ((AVAILABLE_FREE_GB < NEEDED_MIN_FREE_DISK_SPACE_IN_GB)); then
	log_console_error "Less than ${NEEDED_MIN_FREE_DISK_SPACE_IN_GB}GB of free disk space available. Please free some more disk space."
	ARE_PREREQUISITES_MET=false
else
	log_console_info "${AVAILABLE_FREE_GB}GB disk space available."
fi

# Internet connectivity
log_console_step "Check internet connectivity"
set +e
if [[ -n "$(command -v ping)" ]]; then
	if ping -q -c 1 -W 1 dns.google.com >/dev/null; then
		log_console_info "Internet access detected."
	else
		log_console_warning "You have no Internet access. The identification of 3rd party libraries ('01__fernflower_decompile') and security vulnerabilties (05__owasp) will be less effective."
	fi
else
	log_console_warning "'ping' is not available. Please install it to be able to check the Internet connectivity."
fi
set -e

# 01
if [[ "${UNPACK_ACTIVE}" == "true" ]]; then
	log_console_step "Step 01 - Check Fernflower pre-requisites"

	if [[ -z "$(command -v unzip)" || -z "$(command -v sha1sum)" || -z "$(command -v curl)" || -z "$(command -v jq)" ]]; then
		if [[ "${IS_MAC}" == "true" ]]; then
			log_console_error "'curl', 'jq', 'sha1sum', and 'unzip' are not all available.
	[MacOS] Installation with brew:
	$ brew install jq md5sha1sum unzip"
		else
			log_console_error "'curl', 'jq', 'sha1sum', and 'unzip' are not all available.
	[CentoOS/RHEL/Fedora] Installation with yum:
	$ sudo yum -y install jq curl unzip"
		fi
		ARE_PREREQUISITES_MET=false
	fi
fi

# 03
if [[ "${WINDUP_ACTIVE}" == "true" ]]; then
	log_console_step "Step 03 - Check Windup pre-requisites"
	if [[ -z "$(command -v xmllint)" || -z "$(command -v xsltproc)" ]]; then
		log_console_error "'xmllint' and 'xsltproc' are not available. Please install them."
		ARE_PREREQUISITES_MET=false
	fi
	if [ -f "${DIST_DIR}/rhamt-cli-${RHAMT_VERSION_SHORT}-offline.zip" ]; then
		log_console_info "'rhamt-cli-${RHAMT_VERSION_SHORT}-offline.zip' present."
	elif [ -f "${DIST_DIR}/tax-cli-${TAX_VERSION}-offline.zip" ]; then
		log_console_info "'tax-cli-${TAX_VERSION}-offline.zip' present."
	else
		log_console_error "Neither TAX nor RHAMT is available. Please add one to '${DIST_DIR}'."
		ARE_PREREQUISITES_MET=false
	fi
	if [[ -z "${WINDUP_INCLUDE_PACKAGES_FILE}" && -z "${WINDUP_EXCLUDE_PACKAGES_FILE}" ]]; then
		log_console_warning "Windup Analysis is active, but no list of packages to include/exclude has been set. It might take a long time to run."
	fi
fi

# 06
if [[ "${SCANCODE_ACTIVE}" == "true" ]]; then
	log_console_step "Step 06 - Check ScanCode pre-requisites"

	# Validate the presencee of python
	if [[ -z "$(command -v python2.7)" ]]; then
		if [[ "${IS_MAC}" == "true" ]]; then
			log_console_error "Python 2.7 is not available. Please install it ([MacOS] '$ brew install python@2') or disable the ScanCode analyzer."
		else
			log_console_error "Python 2.7 is not available. Please install it ([CentoOS/RHEL/Fedora] '$ sudo yum -y install python2-devel') or disable the ScanCode analyzer."
		fi
		ARE_PREREQUISITES_MET=false
	fi
	if [[ -z "$(command -v bzip2)" ]]; then
		if [[ "${IS_MAC}" == "true" ]]; then
			log_console_error "'bzip2' is not available. Please install it ([MacOS] '$ brew install bzip2') or disable Scancode."
		else
			log_console_error "'bzip2' is not available. Please install it ([CentoOS/RHEL/Fedora] '$ sudo yum -y install bzip2') or disable Scancode."
		fi
		ARE_PREREQUISITES_MET=false
	fi
	if [[ -z "$(command -v xz)" ]]; then
		if [[ "${IS_MAC}" == "true" ]]; then
			log_console_error "'xz' is not available. Please install it ([MacOS] '$ brew install xz') or disable Scancode."
		else
			log_console_error "'xz' is not available. Please install it ([CentoOS/RHEL/Fedora] '$ sudo yum -y install xz') or disable Scancode."
		fi
		ARE_PREREQUISITES_MET=false
	fi
	# Check if bzip2 is properly installed
	if [[ -n "$(command -v yum)" ]]; then
		if [ ! -f "/usr/lib64/libbz2.so.1.0" ]; then
			log_console_error "'libbz2' library is not properly installed. Please execute the following command to fix it:
	$ sudo ln -s \$(find /usr/lib64/ -type f -name \"libbz2.so.1*\") /usr/lib64/libbz2.so.1.0"
			ARE_PREREQUISITES_MET=false
		fi
	fi
fi

# 08
if [[ "${LANGUAGES_ACTIVE}" == "true" ]]; then
	log_console_step "Step 08 - Check Linguist pre-requisites"
	# Check if docker is present
	if [[ -z "$(command -v docker)" ]]; then
		if [[ "${IS_MAC}" == "true" ]]; then
			log_console_error "'docker' is not available. Please install it and start the docker daemon or disable Linguist.
	[MacOS] Install docker (UI required) with brew and start its daemon 
		$ brew install docker
		$ brew cask install docker
		$ open /Applications/Docker.app"
		else
			log_console_error "'docker' is not available. Please install it and start the docker daemon or disable Linguist.
	[CentoOS/RHEL/Fedora] Install docker and start its daemon 
		$ sudo yum install -y yum-utils device-mapper-persistent-data lvm2
		$ sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
		$ sudo yum -y install docker-ce docker-ce-cli --nobest
		$ sudo groupadd docker
		$ sudo usermod -aG docker ${USER}
		$ sudo mkdir -p /etc/systemd/system/docker.service.d
		$ sudo systemctl start docker"
		fi
		ARE_PREREQUISITES_MET=false
	else
		# Check if the docker daemon is running
		set +e
		docker stats --no-stream >/dev/null 2>&1
		if [[ ${PIPESTATUS[0]} -ne 0 ]]; then
			if [[ "${IS_MAC}" == "true" ]]; then
				log_console_error "The docker daemon is not running! Please start it ([MacOS] '$ open /Applications/Docker.app')."
			else
				log_console_error "The docker daemon is not running! Please start it ([CentoOS/RHEL/Fedora] '$ sudo systemctl start docker')."
			fi
			ARE_PREREQUISITES_MET=false
		fi
		set -e
	fi
	# Check if git is present
	if [[ -z "$(command -v git)" ]]; then
		if [[ "${IS_MAC}" == "true" ]]; then
			log_console_error "'git' is not available. Please install it ([MacOS] '$ brew install git') or disable Linguist."
		else
			log_console_error "'git' is not available. Please install it ([CentoOS/RHEL/Fedora] '$ sudo yum -y install git') or disable Linguist."
		fi
		ARE_PREREQUISITES_MET=false
	fi
fi

# 09
if [[ "${FSB_ACTIVE}" == "true" ]]; then
	log_console_step "Step 09 - Check Find Security Bugs pre-requisites"
	if [[ -z "$(command -v xmllint)" ]]; then
		log_console_error "'xmllint' is not available. Please install it."
		ARE_PREREQUISITES_MET=false
	fi
fi

# 10
if [[ "${MAI_ACTIVE}" == "true" ]]; then
	log_console_step "Step 10 - Check Microsoft Application Inspector pre-requisites"
	if [[ -z "$(command -v dotnet)" ]]; then
		if [[ "${IS_MAC}" == "true" ]]; then
			log_console_error "'dotnet' is not available. Please install it ([MacOS] '$ brew cask install dotnet') or disable Microsoft Application Inspector."
		else
			log_console_error "'dotnet' is not available. Please install it ([CentoOS/RHEL/Fedora] '$ sudo yum -y install dotnet-sdk-3.0') or disable Microsoft Application Inspector."
		fi
		ARE_PREREQUISITES_MET=false
	elif ! dotnet --list-runtimes | grep Microsoft.NETCore.App | grep -q "${NEEDED_DOTNET_VERSION}"; then
		if [[ "${IS_MAC}" == "true" ]]; then
			log_console_error "The framework 'Microsoft.NETCore.App', version '${NEEDED_DOTNET_VERSION}' was not found. Please install it ([MacOS] '$ brew tap isen-ng/dotnet-sdk-versions; brew install --cask dotnet-sdk3-1-400' https://github.com/isen-ng/homebrew-dotnet-sdk-versions )."
		else
			log_console_error "The framework 'Microsoft.NETCore.App', version '${NEEDED_DOTNET_VERSION}' was not found. Please install it ( https://dotnet.microsoft.com/download/dotnet/3.1 )."
		fi
		ARE_PREREQUISITES_MET=false
	fi
fi

# Conclusion!
if [ "${ARE_PREREQUISITES_MET}" = false ]; then
	[[ "${DEBUG}" == "true" ]] && set +x
	echo ""
	log_console_error "Pre-requisites not satisified. Please fix any errors, then re-run."
	exit 1
else
	log_console_success "All pre-requisites met to start the application analysis."
fi
