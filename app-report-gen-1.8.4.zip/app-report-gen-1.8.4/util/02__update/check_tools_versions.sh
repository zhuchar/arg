#!/usr/bin/env bash

##############################################################################################################
# Independant utility script to check for updates of the used tools.
#
# This script calls a python script (_check_tools_versions.py) and requires python 3.7+ and pip.
##############################################################################################################

SCRIPT_DIR=$(dirname "${BASH_SOURCE[0]}")

# Import all required python libraries
pip install bs4 >>/dev/null
pip install requests >>/dev/null

# Load the current version numbers
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/../../_versions.sh"

# Check for new versions
# shellcheck source=/dev/null
python "${SCRIPT_DIR}/check_tools_versions.py"
