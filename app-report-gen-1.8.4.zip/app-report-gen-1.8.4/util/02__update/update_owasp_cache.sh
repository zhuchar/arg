#!/usr/bin/env bash
# Download and cache locally the NVD and RetireJS databases for the OWASP analysis

SCRIPT_DIR=$(dirname "${BASH_SOURCE[0]}")

CURRENT_DIR=$(pwd)
DIST_DIR="${SCRIPT_DIR}/../../dist"
CACHE_DIR="${DIST_DIR}/owasp_cache"
mkdir -p "${CACHE_DIR}"

# Update RetireJS
RETIRE_JS_URL="https://raw.githubusercontent.com/Retirejs/retire.js/master/repository/jsrepository.json"
wget -q -O "${CACHE_DIR}/jsrepository.json" "${RETIRE_JS_URL}"

# Update local NDV cache
java -jar "${DIST_DIR}/nist-data-mirror.jar" "${CACHE_DIR}/NVD"
