#!/usr/bin/env bash
# Update the imported static content

CURRENT_DIR=$(pwd)
DIST_DIR="${CURRENT_DIR}/dist"
TEMPLATING_DIR="${DIST_DIR}/templating/static"
JS_DIR="${TEMPLATING_DIR}/js"
#CSS_DIR="${TEMPLATING_DIR}/css"
mkdir -p "${JS_DIR}"

# Update Bootstrap Toggle
#wget -q -O "${CSS_DIR}/bootstrap-toggle.min.css" https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css
#wget -q -O "${JS_DIR}/bootstrap-toggle.min.js" https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js

# Update jquery
wget -q -O "${JS_DIR}/jquery-3.5.1.min.js" https://code.jquery.com/jquery-3.5.1.min.js
wget -q -O "${JS_DIR}/d3-scale-chromatic.v1.min.js" https://d3js.org/d3-scale-chromatic.v1.min.js

# Update D3
wget -q -O "${JS_DIR}/d3.v4.min.js" https://d3js.org/d3.v4.min.js

# Loading the latest linguist docker image
docker image rm crazymax/linguist
#docker pull crazymax/linguist:7.12.2
docker pull crazymax/linguist:latest
docker image save crazymax/linguist:latest | gzip >"${DIST_DIR}/docker__linguist_latest.img"
