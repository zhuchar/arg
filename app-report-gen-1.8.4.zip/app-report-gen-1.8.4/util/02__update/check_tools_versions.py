#!/usr/bin/env python
"""This scripts automatically checks for updates on the used tools."""

import os
import json
import re
import requests
from bs4 import BeautifulSoup

# GitHub Personal access token for the CLI - Used for Tanzu Cloud Suitability Analyzer (CSA)
# https://help.github.com/en/github/authenticating-to-github/creating-a-personal-access-token-for-the-command-line

TOKEN = 'ADD_YOUR_TOKEN_HERE'

class color:
    GREEN = '\033[0;32m'
    RED = '\033[0;31m'
    ORANGE = '\033[0;33m'
    BOLD = '\033[1m'
    NORMAL = '\033[0m'

CSA_VERSION_CURRENT = os.getenv('CSA_VERSION')
RHAMT_VERSION_CURRENT = os.getenv('RHAMT_VERSION_SHORT')
WAMT_VERSION_CURRENT = os.getenv('WAMT_VERSION')
CLOC_VERSION_CURRENT = os.getenv('CLOC_VERSION')
SCANCODE_VERSION_CURRENT = os.getenv('SCANCODE_VERSION')
PMD_VERSION_CURRENT = os.getenv('PMD_VERSION')
PMD_GDS_VERSION_CURRENT = os.getenv('PMD_GDS_VERSION') 
OWASP_DC_VERSION_CURRENT = os.getenv('OWASP_DC_VERSION')
FSB_CURRENT = os.getenv('FSB_VERSION')
JQA_VERSION_CURRENT = os.getenv('JQA_VERSION')
MAI_VERSION_CURRENT = os.getenv('MAI_VERSION')
LINGUIST_VERSION_CURRENT = os.getenv('LINGUIST_VERSION') 


def print_warn(message):
    print(color.ORANGE+message+color.NORMAL)

def print_ok(message):
    print(color.GREEN+message+color.NORMAL)

def get_latest_github_version(url, regex):
    """Retrieve the latest released version of a GitHub project."""
    soup = BeautifulSoup(requests.get(url).text, "html.parser")
    prog = re.compile(regex, re.IGNORECASE)
    project_version = ''
    project_href = "https://github.com"

    for anchor in soup.findAll('a', href=True):
        href = anchor['href']
        match = prog.match(href)
        if match:
            project_href = project_href+href
            project_version = match.group(1)
            break

    return project_version, project_href

def check_latest_github_version(url, regex, name, project_version_current):
    """Check if the current used versions is the latest released one foor a GitHub project."""
    project_version, project_href = get_latest_github_version(url, regex)
    if project_version != project_version_current:
        print_warn(name+' - New version available: '+project_version)
        print(''+name+' - Download: '+project_href)
    else:
        print_ok(name+' - Version up-to-date: '+project_version)

def check_latest_rhamt_version(url, regex, project_version_current):
    """Check if the current used RHAMT version is the latest released one."""
    response = requests.get(url).text
    href = json.loads(response)[0]['productVersions'][0]['files'][1]['url']
    prog = re.compile(regex, re.IGNORECASE)
    rhamt_version = ''
    rhamt_href = ''
    match = prog.match(href)
    if match:
        rhamt_href = href
        rhamt_version = match.group(1)

    if rhamt_version != project_version_current:
        print_warn('RHAMT - New version available: '+rhamt_version)
        print('RHAMT - Download: '+rhamt_href)
    else:
        print_ok('RHAMT - Version up-to-date: '+rhamt_version)

def check_latest_wamt_version(url, regex, project_version_current):
    """Check if the current used WAMT version is the latest released one."""
    soup = BeautifulSoup(requests.get(url).text, "html.parser")
    result = soup.body.findAll(text=re.compile(regex, re.IGNORECASE))
    if result:
        print_ok('WAMT - Version up-to-date: '+project_version_current)
    else:
        download = 'https://public.dhe.ibm.com/ibmdl/export/pub/software/websphere/wasdev/downloads/wamt/ApplicationBinaryTP/binaryAppScannerInstaller.jar'
        print_warn('WAMT - New version available!')
        print('WAMT - Download: '+download)

def check_latest_csa_version(url, project_version_current, token):
    """Check if the current used CSA version is the latest released one."""
    headers = {'Authorization': 'TOKEN ' + token}
    session = requests.session()
    response = session.get(url, headers=headers).text
    csa_version = json.loads(response)[0]['tag_name']    
    if csa_version != ('v'+project_version_current):
        print_warn('CSA - New version available: '+csa_version)
        print('CSA - Download: https://github.com/vmware-tanzu/cloud-suitability-analyzer/releases/latest and merge the new rules [./csa rules export --rules-dir=""] in CSA/default-rules') 
    else:
        print_ok('CSA - Version up-to-date: '+csa_version)

## PMD
check_latest_github_version(
    'https://github.com/pmd/pmd/releases/latest',
    r'.*pmd-bin-(.*)\.zip',
    'PMD',
    PMD_VERSION_CURRENT)

## PMD GDS
check_latest_github_version(
    'https://github.com/albfernandez/GDS-PMD-Security-Rules/releases/latest',
    r'.*pmd-gds-(.*)-javadoc\.jar',
    'PMD GDS',
    PMD_GDS_VERSION_CURRENT)

## OWASP DC
check_latest_github_version(
    'https://github.com/jeremylong/DependencyCheck/releases/latest',
    r'.*dependency-check-(.*)-release\.zip',
    'OWASP DC',
    OWASP_DC_VERSION_CURRENT)

## FSB_VERSION
check_latest_github_version(
    'https://github.com/find-sec-bugs/find-sec-bugs/releases/latest',
    r'.*findsecbugs-cli-(.*)\.zip',
    'Find Security Bugs',
    FSB_CURRENT)

## ScanCode
check_latest_github_version(
    'https://github.com/nexB/scancode-toolkit/tags',
    r'.*v(.*)\.zip',
    'ScanCode',
    SCANCODE_VERSION_CURRENT)
print('    (( ScanCode v.3.2.3 is not easily usable as it requires a very specific Python version. Should switch to container distribution. ))')
## CLOC
check_latest_github_version(
    'https://github.com/AlDanial/cloc/releases/latest',
    r'.*cloc-(.*)\.tar\.gz',
    'CLOC',
    CLOC_VERSION_CURRENT)

## RHAMT
check_latest_rhamt_version(
    'https://developers.redhat.com/download-manager/rest/available/migrationtoolkit',
    r'.*migrationtoolkit-mta-cli-(.*)-offline\.zip',
    RHAMT_VERSION_CURRENT)

## CSA
check_latest_csa_version(
    'https://api.github.com/repos/vmware-tanzu/cloud-suitability-analyzer/releases',
    CSA_VERSION_CURRENT,
    TOKEN)

## MAI
check_latest_github_version(
    'https://github.com/microsoft/ApplicationInspector/releases/latest',
    r'.*ApplicationInspector_netcoreapp_(.*)\.zip',
    'MAI',
    MAI_VERSION_CURRENT)
#print('    (( MAI v.1.2.61 is not usable. ))')

## Linguist
check_latest_github_version(
    'https://github.com/github/linguist/releases/latest',
    r'/github/linguist/tree/v(.*)',
    'Linguist',
    LINGUIST_VERSION_CURRENT)

## WAMT
check_latest_wamt_version(
    'https://public.dhe.ibm.com/ibmdl/export/pub/software/websphere/wasdev/downloads/wamt/ApplicationBinaryTP/',
    r'.*(19-Nov-2020.*10:11).*',
    WAMT_VERSION_CURRENT)