#!/usr/bin/env bash

##############################################################################################################
# Install and add all pre-requisites needed to run ARG on CentOS
#
# Example on how to copy a file to a vagrant virtual machine:
# vagrant scp /usr/mzottner/app-report-gen-tmp/backup/app-report-gen.zip arg-centos:/tmp/arg.zip
##############################################################################################################

# --- To be changed
export USER='vagrant'
export GROUP='vagrant'
export ARG_DIR='/opt/arg'
export ARG_ZIP='/tmp/arg.zip'

# --- Don't change
export ULIMIT_FILE_DEST='/etc/security/limits.d/nofile.conf'

# Update OS
sudo yum -y update

# Install required RPM dependencies
sudo yum -y install lvm2 wget rsync net-tools curl jq unzip java-11-openjdk-devel dotnet-sdk-3.0 python2-devel bzip2-devel git

wget 'https://download.docker.com/linux/centos/docker-ce.repo'
sudo mv 'docker-ce.repo' '/etc/yum.repos.d/docker-ce.repo'

mkdir -p ${ARG_DIR}
unzip ${ARG_ZIP} -d ${ARG_DIR}

cat >>'nofile.conf' <<EOF
*    soft    nofile 100000
*    hard    nofile 100000
EOF

sudo mv 'nofile.conf' ${ULIMIT_FILE_DEST}
sudo chown root:root ${ULIMIT_FILE_DEST}
sudo chmod 0644 ${ULIMIT_FILE_DEST}
sudo chown -R ${USER}:${GROUP} ${ARG_DIR}

# Resize disk to maximum (only for vagrant to free more than 10Gb disk)
#sudo echo -e "yes\n100" | sudo parted /dev/sda ---pretend-input-tty unit % resizepart 1;
#sudo fdisk -l /dev/sda;
#sudo fsadm resize /dev/sda1

# Fix libbz2
sudo rm -f /usr/lib64/libbz2.so.1.0
sudo ln -s $(find /usr/lib64/ -type f -name "libbz2.so.1*") /usr/lib64/libbz2.so.1.0

# Install, enable, andd start docker (docker-ce)
sudo yum -y install docker-ce --nobest
sudo systemctl enable docke
sudo groupadd docker
sudo usermod -aG docker $USER
sudo systemctl start docker

echo "Please reboot your machine for the changes to take effect."

# Generate a test report
#export ARG_DIR='/tmp/arg'
#cd "${ARG_DIR}/app-report-gen" || exit
#./run.sh -a
