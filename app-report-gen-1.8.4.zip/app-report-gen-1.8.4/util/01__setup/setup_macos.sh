#!/usr/bin/env bash

##############################################################################################################
# Install and add all pre-requisites needed to run ARG on MacOS
##############################################################################################################

SCRIPT_DIR=$(dirname "${BASH_SOURCE[0]}")

# Install brew and xcode CLI (echo -e "\n")
if type brew >/dev/null; then
	echo ">>> Already installed: brew"
else
	echo '>>> Installing brew - The Missing Package Manager for macOS'
	/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# Install a compativle Bash version if necessary
MAJOR_BASH_VERSION=$(echo "${BASH_VERSION}" | cut -d . -f 1)
if ((MAJOR_BASH_VERSION < 4)); then
	brew install bash
	# Set latest bash as default
	BASH_VERSION=$(brew list --versions bash | sort | tail -1 | cut -d ' ' -f 2)
	BASH_LINK="/usr/local/Cellar/bash/${BASH_VERSION}/bin/bash"
	SHELLS="/etc/shells"
	if ! grep -q "${BASH_LINK}" "${SHELLS}"; then
		sudo bash -c "echo ${BASH_LINK} >> /etc/shells"
		chsh -s "${BASH_LINK}"
	fi
else
	echo ">>> Already installed: bash"
fi

declare -A required_brew
required_brew['getopt']='gnu-getopt'
required_brew['curl']='curl'
required_brew['wget']='wget'
required_brew['python']='python'
required_brew['unzip']='unzip'
required_brew['jq']='jq'
required_brew['sha1sum']='md5sha1sum'
required_brew['xz']='xz'
required_brew['git']='git'

# Install getopt, curl, wget, python, bash, jq, md5sha1sum, xz, git
for i in "${!required_brew[@]}"; do
	command="${i}"
	software="${required_brew[$i]}"
	if type "${command}" >/dev/null; then
		echo ">>> Already installed: ${software}"
	else
		echo ">>> Installing ${software}"
		brew install "${software}"
	fi
done

if type dotnet >/dev/null; then
	echo ">>> Already installed: dotnet-sdk"
else
	brew cask install dotnet-sdk
fi

if dotnet --list-runtimes | grep Microsoft.NETCore.App | grep -q '3.1'; then
	echo ">>> Already installed: dotnet-sdk 3.1"
else
	brew tap isen-ng/dotnet-sdk-versions
	brew install --cask dotnet-sdk3-1-400
fi

if type docker >/dev/null; then
	echo ">>> Already installed: docker"
else
	brew cask install docker
	open /Applications/Docker.app
fi

# Install sdkman
SDKMAN_INIT="${HOME}/.sdkman/bin/sdkman-init.sh"
if [[ -f "${SDKMAN_INIT}" ]]; then
	echo ">>> Already installed: sdkman"
else
	echo "Install sdk"
	curl -s "https://get.sdkman.io" | bash
fi

# Install latest compatible Java 11 version
source "${SDKMAN_INIT}"
JAVA_11_LATEST=$(sdk ls java | grep -v sdk | grep hs-adpt | grep '11.' | sort | tail -1 | tr -d ' ' | rev | cut -d '|' -f 1 | rev)
sdk install java "${JAVA_11_LATEST}"
sdk default java "${JAVA_11_LATEST}"

source "${SCRIPT_DIR}/set_ulimit.sh"
