#!/usr/bin/env bash

[[ "$DEBUG" == "true" ]] && set -x

set -eu

export CURRENT_DIR

CURRENT_DIR=$(pwd)

pushd "$(dirname "$0")" &>/dev/null
# shellcheck source=/dev/null
source "${CURRENT_DIR}/_versions.sh"

mkdir -p dist

echo "Downloading CSA"
echo "[ERROR] CSA cannot be downloaded automatically - please manually download."

echo "Compiling & packaging Bagger"
mvn -v >/dev/null 2>&1 || { echo >&2 "[ERROR] Maven is required for Bagger, but not installed."; }
mvn -f dist/bagger assembly:assembly
cp dist/bagger/target/*-with-dependencies.jar dist/bagger.jar

echo "Downloading RHAMT"
echo "[ERROR] RHAMT cannot be downloaded automatically - please manually download from https://developers.redhat.com/products/rhamt/download"

echo "Downloading WAMT"
echo "[ERROR] WAMT cannot be downloaded automatically - please manually download from https://developer.ibm.com/wasdev/downloads/#asset/tools-Migration_Toolkit_for_Application_Binaries"

echo "Downloading OWASP Dependency Check"
wget -q -O "dist/owasp-dependency-check-${OWASP_DC_VERSION}.zip" \
	"https://dl.bintray.com/jeremy-long/owasp/dependency-check-${OWASP_DC_VERSION}-release.zip"

echo "Downloading Scancode Toolkit"
wget -q -O "dist/scancode-toolkit-${SCANCODE_VERSION}.zip" \
	"https://github.com/nexB/scancode-toolkit/releases/download/v${SCANCODE_VERSION}/scancode-toolkit-${SCANCODE_VERSION}.zip"

echo "Downloading PMD"
wget -q -O "dist/pmd-bin-${PMD_VERSION}.zip" \
	"https://github.com/pmd/pmd/releases/download/pmd_releases%2F${PMD_VERSION}/pmd-bin-${PMD_VERSION}.zip"

echo "Downloading Fernflower"
[[ ! -e dist/intellij-community ]] && git clone --depth 1 https://github.com/JetBrains/intellij-community.git dist/intellij-community
pushd dist/intellij-community/plugins/java-decompiler/engine/ &>/dev/null
# Old version of Gradle doesn't build with Java 9 or later...
sed -i "" -Ee 's/distributionUrl=(.*)gradle-4.0-all.zip/distributionUrl=\1gradle-5.6.2-all.zip/g' gradle/wrapper/gradle-wrapper.properties
GRADLE_OPTS="-Dorg.gradle.daemon=false" ./gradlew assemble
popd &>/dev/null
cp dist/intellij-community/plugins/java-decompiler/engine/build/libs/fernflower.jar dist/
rm -Rf dist/intellij-community # Keeping it makes running some other scripts a lot slower...
