#!/usr/bin/env bash

##############################################################################################################
# Install and add all pre-requisites needed to run ARG on Docker
##############################################################################################################

# --- Don't change
export ULIMIT_FILE_DEST='/etc/security/limits.d/nofile.conf'

# Update OS
yum -y update

# Install required RPM dependencies
yum -y install lvm2 wget rsync net-tools curl jq unzip java-11-openjdk-devel dotnet-sdk-3.0 python2-devel bzip2-devel git bzip2 libxml2-devel libxslt-devel glibc-locale-source glibc-langpack-en

# Set local for ScanCode
localedef -i en_US -f UTF-8 en_US.UTF-8

cat >>'nofile.conf' <<EOF
*    soft    nofile 100000
*    hard    nofile 100000
EOF

mv 'nofile.conf' ${ULIMIT_FILE_DEST}
chmod 0644 ${ULIMIT_FILE_DEST}

# Fix libbz2
rm -f /usr/lib64/libbz2.so.1.0
ln -s $(find /usr/lib64/ -type f -name "libbz2.so.1*") /usr/lib64/libbz2.so.1.0

