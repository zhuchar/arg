#!/usr/bin/env bash
# This script bundles scripts and binaries in one zip file.

export CURRENT_DIR TMP_DIR

CURRENT_DIR=$(pwd)
TMP_DIR="${CURRENT_DIR}/../temp"

set -x

rm -Rf "${TMP_DIR}"
mkdir -p "${TMP_DIR}"

cp -Rfp "${CURRENT_DIR}"/../app-report-gen "${TMP_DIR}/."

pushd "${TMP_DIR}/app-report-gen" &>/dev/null || exit

# Cleanup
rm -Rf bin apps apps_ reports py_* .vscode* dist/*.old dist/rhamt* dist/spotbugs*
rm -Rf dist/bootifier.tar.gz dist/discotek.deepdive-* dist/bootstrap-*.zip dist/scc* dist/jqa* dist/aws*
rm -Rf docker helm docs test util/release dist/bagger/target .DS_Store app-report-gen/dist/.DS_Store conf/.DS_Store
rm -Rf conf/CSA/default-rules/*.yaml conf/CSA/*.yaml

# Remove .DS_Store files
find . -name '.DS_Store' -type f -delete

git fetch origin
git reset --hard origin/master
git clean -f

rm -Rf .git .gitignore
rm -Rf site tmp
rm -f 11__scc__01__analysis.sh util/bundle_scripts.sh util/setup_vm.sh
mkdir -p reports apps bin
rm -Rf dist/bagger/.*

cp -Rfp "${CURRENT_DIR}/../app-report-gen-tmp/apps_tmp/collections/test-application" apps/.

cd .. || exit

DATE=$(date +%Y_%m_%d)

echo "zip -r app-report-gen__${DATE}.zip app-report-gen >>/dev/null 2>&1"

zip -r "app-report-gen__${DATE}.zip" app-report-gen >>/dev/null 2>&1

# List of files for comparison purposes
#unzip -l "app-report-gen__${DATE}.zip" > ~/Work/Tools/app/app-report-gen-tmp/backup/app-report-gen__"${DATE}".zip.txt
unzip -l "app-report-gen__${DATE}.zip" | sed '1,2d;$d' | awk '{ print $4 " - Size:" $1}' | tail -n +2 | tail -r | tail -n +2 | tail -r | sort >../app-report-gen-tmp/backup/app-report-gen__"${DATE}".zip.txt

mv "app-report-gen__${DATE}.zip" ../app-report-gen-tmp/backup
popd &>/dev/null || exit

rm -Rf "${TMP_DIR}"

set +x

echo "Tools bundled: ~/Work/Tools/app/app-report-gen-tmp/backup/  (${DATE})"
