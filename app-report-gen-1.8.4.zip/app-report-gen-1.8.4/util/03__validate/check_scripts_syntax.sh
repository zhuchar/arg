#!/usr/bin/env bash

##############################################################################################################
# Independant utility script to check the syntax of all scripts.
##############################################################################################################

SCRIPT_DIR=$(dirname "${BASH_SOURCE[0]}")
ARG_DIR="${SCRIPT_DIR}/../.."

while read -r SCRIPT; do
	bash -n "${SCRIPT}"
	COUNT=$(shellcheck "${SCRIPT}" -x | grep -c "In .* line [0-9]*:" || true)
	echo "Shellcheck issues: ($(basename "${SCRIPT}"))              ${COUNT}"
done < <(find "${ARG_DIR}" -maxdepth 3 -mindepth 1 -type f -name '*.sh' | sort)

COUNT="$(shellcheck "${ARG_DIR}"/*.sh -x | grep -c "In .* line [0-9]*:" || true)"
echo "Shellcheck issues: (ALL)              ${COUNT}"

while read -r SCRIPT; do
	# Install: pip install --upgrade pyflakes
	# https://github.com/PyCQA/pyflakes
	echo "PyFlakes"
	python -m pyflakes "${SCRIPT}"

	# Install: pip install pylint --upgrade
	# https://github.com/PyCQA/pylint/
	echo "PyLint"
	pylint "${SCRIPT}" | grep -v "C0301" | grep -v '^[- ]*$'
done < <(find "${ARG_DIR}/util" -maxdepth 3 -mindepth 1 -type f -name '*.py' | sort)
