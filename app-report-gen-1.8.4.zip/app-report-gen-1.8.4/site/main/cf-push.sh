#!/usr/bin/env bash

CF_APP_NAME=tanzu-app-reports
BACKEND_APPS="tanzu-arg-small tanzu-arg-medium tanzu-arg-large"
DOMAIN_INTERNAL=apps.internal
DOMAIN_PUBLIC=apps.pcfone.io

SCRIPT_DIR=$(dirname "${BASH_SOURCE[0]}")
PUBLIC_DIR="${SCRIPT_DIR}/public"
STATIC_DIR="${PUBLIC_DIR}/static"

CF_CLI_VERSION=$(cf version | cut -d' ' -f 3 | head -c 1)

# Remove static content
function delete_static_content() {
	rm -Rf "${STATIC_DIR}/bootstrap-4.5.3-dist"
	rm -Rf "${STATIC_DIR}/css"
	rm -Rf "${STATIC_DIR}/fonts"
	rm -f "${STATIC_DIR}/img/favicon.ico"
	rm -f "${PUBLIC_DIR}/favicon.ico"
	rm -Rf "${STATIC_DIR}/js"
}

# Copies static content
function copy_static_content() {
	cp -Rfp "${SCRIPT_DIR}/../../dist/templating/static/bootstrap-4.5.3-dist" "${STATIC_DIR}/."
	cp -Rfp "${SCRIPT_DIR}/../../dist/templating/static/css" "${STATIC_DIR}/."
	cp -Rfp "${SCRIPT_DIR}/../../dist/templating/static/fonts" "${STATIC_DIR}/."
	cp -fp "${SCRIPT_DIR}/../../dist/templating/static/img/favicon.ico" "${STATIC_DIR}/img"
	cp -fp "${SCRIPT_DIR}/../../dist/templating/static/img/favicon.ico" "${PUBLIC_DIR}"
	mkdir -p "${STATIC_DIR}/js"
	cp -fp "${SCRIPT_DIR}/../../dist/templating/static/js/jquery-3.5.1.min.js" "${STATIC_DIR}/js"
}

# CF push!
function cf_push() {
	if [[ "${CF_CLI_VERSION}" == "7" ]]; then

		# Delete app
		cf d -f "${CF_APP_NAME}"

		for APP in ${BACKEND_APPS}; do
			cf delete-route "${DOMAIN_INTERNAL}" --hostname "${APP}" -f
		done

		cf create-app "${CF_APP_NAME}"
		cf apply-manifest -f manifest.yml
		cf push "${CF_APP_NAME}"

		for APP in ${BACKEND_APPS}; do
			# Add network policy to connect apps
			cf add-network-policy "${CF_APP_NAME}" "${APP}"
			# Connect apps internally
			cf map-route "${APP}" "${DOMAIN_INTERNAL}" --hostname "${APP}"
			# Disable public domains
			cf delete-route "${DOMAIN_PUBLIC}" --hostname "${APP}" -f
		done
	else
		echo "Invalid CF CLI version. Please install CF CLI v7 following instructions on https://github.com/cloudfoundry/cli"
	fi
}

function main() {
	delete_static_content
	copy_static_content
	cf_push
	delete_static_content
}

main
