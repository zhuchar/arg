#!/usr/bin/env bash

# Current version of app-report-gen
export TOOL_VERSION='1.8.4'

# List of the versions for all tools in use.

# Migration & cloud readiness
export CSA_VERSION='3.2.5-rc1'
export TAX_VERSION_SHORT='4.3.1'
export TAX_VERSION="${TAX_VERSION_SHORT}.Final"
export RHAMT_VERSION_SHORT='4.3.1'
export RHAMT_VERSION="${RHAMT_VERSION_SHORT}.Final"
export WAMT_VERSION='20.0.0.4'

# Languages
export LINGUIST_VERSION='7.13.0'
export CLOC_VERSION='1.88'

# License & Authors
export SCANCODE_VERSION='3.0.2'

# Code quality / bugs
export MAI_VERSION='1.2.95'
export PMD_VERSION='6.32.0'
export JQA_VERSION='1.8.0'
export SCC_VERSION='2.12.0'

# Security
export PMD_GDS_VERSION='2.24.0'
export OWASP_DC_VERSION='6.1.2'
export FSB_VERSION='1.11.0'

# True scancode version identified dynamically
SCANCODE_VERSION_TMP="${SCANCODE_VERSION}"
if [[ -n "$(command -v scancode)" ]]; then
	set +e
	SCANCODE_VERSION_LOCAL=$(scancode --version 2>/dev/null | grep "ScanCode version" | rev | cut -d ' ' -f 1 | rev)
	RC=$?
	if [[ ${RC} -eq 0 ]] && [[ -n "${SCANCODE_VERSION_LOCAL}" ]]; then
		SCANCODE_VERSION_TMP="${SCANCODE_VERSION_LOCAL}"
	fi
	set -e
fi
export SCANCODE_VERSION_DYNAMIC="${SCANCODE_VERSION_TMP}"
