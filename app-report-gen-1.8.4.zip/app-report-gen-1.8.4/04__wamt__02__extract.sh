#!/usr/bin/env bash
# This script extracts results out of the generated WAMT HTML files.

# ----- Please adjust

# ------ Do not modify
VERSION=${WAMT_VERSION}
STEP=$(get_step)
SEPARATOR=","
APP_DIR_OUT=${REPORTS_DIR}/${STEP}__WAMT__${VERSION}
export LOG_FILE=${APP_DIR_OUT}.log

function generate_csv() {
	APP_DIR_INCOMING=${1}
	GROUP=$(basename "${APP_DIR_INCOMING}")

	if [[ ! -d "${APP_DIR_OUT}" ]]; then
		LOG_FILE=/dev/null
		log_console_error "WAMT result directory does not exist: ${APP_DIR_OUT}"
		exit
	fi

	log_analysis_message "group '${GROUP}'"

	RESULT_FILE="${APP_DIR_OUT}/${GROUP}___results_extracted.csv"

	echo "Applications${SEPARATOR}WAMT severes${SEPARATOR}WAMT warns${SEPARATOR}WAMT total" >"${RESULT_FILE}"

	while read -r FILE; do
		APP="$(basename "${FILE}")"
		#log_analysis_message "app '${APP}'"

		WAMT_FILE="${APP_DIR_OUT}/${GROUP}__${APP}.html"
		if [[ -f "${WAMT_FILE}" ]]; then
			TEMP_TABLE_FILE="${RESULT_FILE}.tmp"
			sed -n '/<table summary="This table summarizes how many rules and rule results are included in the report for each rule severity. A description for each rule severity is also provid*/,/<\/table>/p' "${WAMT_FILE}" >"${TEMP_TABLE_FILE}"
			if [ -s "${TEMP_TABLE_FILE}" ]; then
				# Very ugly but works to make sure that we capture the right value
				VALUES=$(grep "<td class=\"center\">" "${TEMP_TABLE_FILE}" |
					sed -n '1d;p;n' |
					sed 's:^<td class="center">\([0-9]*\)</td>:\1:g' |
					tr '\n' ',' |
					awk -F "," '{printf("%s,%s,%s", $1, $2, $3)}')

				KEYS=$(grep "<td class=\"severity-label\">" "${TEMP_TABLE_FILE}" |
					sed 's:^<td class="severity-label"><a[^>]*>\([^<]*\)<.*:\1:g' |
					tr '\n' ',')

				FIRST=$(echo "${KEYS}" | cut -d',' -f1)
				SECOND=$(echo "${KEYS}" | cut -d',' -f2)
				THIRD=$(echo "${KEYS}" | cut -d',' -f3)
				FIRST_VALUE=$(echo "${VALUES}" | cut -d',' -f1)
				SECOND_VALUE=$(echo "${VALUES}" | cut -d',' -f2)
				THIRD_VALUE=$(echo "${VALUES}" | cut -d',' -f3)

				SEVERES="0"
				INFOS="0"
				WARNINGS="0"

				if [[ "${FIRST}" == "Warning" ]]; then
					WARNINGS="${FIRST_VALUE}"
				elif [[ "${FIRST}" == "Severe" ]]; then
					SEVERES="${FIRST_VALUE}"
				elif [[ "${FIRST}" == "Information" ]]; then
					INFOS="${FIRST_VALUE}"
				fi

				if [[ "${SECOND}" == "Warning" ]]; then
					WARNINGS="${SECOND_VALUE}"
				elif [[ "${SECOND}" == "Severe" ]]; then
					SEVERES="${SECOND_VALUE}"
				elif [[ "${SECOND}" == "Information" ]]; then
					INFOS="${SECOND_VALUE}"
				fi

				if [[ "${THIRD}" == "Warning" ]]; then
					WARNINGS="${THIRD_VALUE}"
				elif [[ "${THIRD}" == "Severe" ]]; then
					SEVERES="${THIRD_VALUE}"
				elif [[ "${THIRD}" == "Information" ]]; then
					INFOS="${THIRD_VALUE}"
				fi

				TOTAL=$((SEVERES + WARNINGS + INFOS))
				echo "${APP}${SEPARATOR}${SEVERES}${SEPARATOR}${WARNINGS}${SEPARATOR}${TOTAL}" >>"${RESULT_FILE}"
			else
				echo "${APP}${SEPARATOR}0${SEPARATOR}0${SEPARATOR}0" >>"${RESULT_FILE}"
			fi
			rm "${TEMP_TABLE_FILE}"
		else
			echo "${APP}${SEPARATOR}n/a${SEPARATOR}n/a${SEPARATOR}n/a" >>"${RESULT_FILE}"
		fi

	done <"${REPORTS_DIR}/list__${GROUP}__all_apps.txt"

	log_console_success "Results: ${RESULT_FILE}"
}

function main() {
	for_each_group generate_csv
}

main
