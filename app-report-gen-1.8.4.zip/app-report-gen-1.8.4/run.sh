#!/usr/bin/env bash
set -eu

# ------ Do not modify START
B=$(tput bold)
N=$(tput sgr0)

export LANG="en_US.utf8"
export LC_ALL="en_US.UTF-8"
export LC_CTYPE="en_US.UTF-8"

export TIMESTAMP CURRENT_DIR REPORTS_DIR
TIMESTAMP=$(date +%Y_%m_%d__%H_%M_%S)

pushd "$(dirname "${0}")" &>/dev/null
CURRENT_DIR=$(pwd)
popd &>/dev/null

export APP_DIR_IN=${CURRENT_DIR}/apps
export DIST_DIR=${CURRENT_DIR}/dist
export INSTALL_DIR=${CURRENT_DIR}/bin

# shellcheck source=./_shared_functions.sh
source "${CURRENT_DIR}/_shared_functions.sh"

# Import tool version numbers
# shellcheck source=./_versions.sh
source "${CURRENT_DIR}/_versions.sh"

# ------ Do not modify END

function usage() {
	printf "usage: ${B}%-8s${N} [-d | --import-dir <dir>] [-g | --app-group <name>] [-a | --all] [-p | --csa]\n" "$(basename "$0")"
	echo "                [-x | --tax] [--include-packages <file>] [--exclude-packages <file>] [-w | --wamt] [-o | --owasp]"
	echo "                [-f | --fsb] [-l | --languages] [-s | --scancode] [-m | --pmd] [-y | --package-discovery]"
	echo "                [-b | --debug] [-r | --reports] [-e | --pre-analysis] [-t | --timestamp] [-v | --version] [-h | --help]"
	echo ""
	echo "${B}SELECT APPS${N}  -----------------------------------------------------------------------------------------------"
	echo "              ${B}-d${N}, ${B}--import-dir${N} <dir>         Import and analyze apps in <dir> (sub-folder of 'apps')"
	echo "              ${B}-g${N}, ${B}--app-group${N} <name>         Analyze only the apps in the group <name> (sub-folder of 'apps')"
	echo ""
	echo "${B}SELECT TOOLS${N}  ----------------------------------------------------------------------------------------------"
	echo "  ${B}General${N}     ${B}-a${N}, ${B}--all${N}                      Run all available tools (${B}-pxwoflsm${N})"
	echo ""
	echo "  ${B}Cloud${N}       ${B}-p, ${B}--csa${N}                      Decompile and run the CSA analysis"
	echo "              ${B}-x, ${B}--tax${N}                      Run the Tanzu Application eXplorer (TAX) tool"
	echo "                 ${B}--include-packages${N} <file>   File containing Java packages to include in TAX analysis"
	echo "                 ${B}--exclude-packages${N} <file>   File containing Java packages to exclude from TAX analysis"
	echo "              ${B}-w${N}, ${B}--wamt${N}                     Run the WebSphere Application Server Migration Toolkit analysis"
	echo ""
	echo "  ${B}Security${N}    ${B}-o${N}, ${B}--owasp${N}                    Run the OWASP Dependency Check analysis"
	echo "              ${B}-f${N}, ${B}--fsb${N}                      Decompile and run the FindSecBugs analysis"
	echo ""
	echo "  ${B}Languages${N}   ${B}-l${N}, ${B}--languages${N}                Decompile and run the Linguist and CLOC analysis"
	echo ""
	echo "  ${B}Licensing${N}   ${B}-s${N}, ${B}--scancode${N}                 Decompile and run the ScanCode analysis"
	echo ""
	echo "  ${B}Quality${N}     ${B}-m${N}, ${B}--pmd${N}                      Decompile and run the PMD Code analysis"
	echo "              ${B}-i${N}, ${B}--mai${N}                      Decompile and run the Microsoft Application Inspector analysis"
	echo ""
	echo "${B}REPORTING${N}  -----------------------------------------------------------------------------------------------"
	echo "              ${B}-z${N}, ${B}--zip${N}                      Zip the generated reports"
	echo "              ${B}-c${N}, ${B}--cf${N}                       Package the generated reports for cloud foundry deployment"
	echo "              ${B}-r${N}, ${B}--reports${N}                  Re-generate the HTML reports"
	echo "              ${B}-t${N} <timestamp>                 Set a timestamp for the analysis (e.g. ${TIMESTAMP})"
	echo ""
	echo "${B}ADVANCED${N}  ------------------------------------------------------------------------------------------------"
	echo "              ${B}-e${N}, ${B}--pre-analysis${N}             Run a pre-configuration analysis"
	echo "              ${B}-y${N}, ${B}--package-discovery${N}        Run the TAX package discovery. Used to configure a TAX analysis"
	echo "              ${B}-b${N}, ${B}--debug${N}                    Enable debug mode"
	echo "              ${B}-v${N}, ${B}--version${N}                  Display the version numbers"
	echo "              ${B}-h${N}, ${B}--help${N}                     Show this help message"
	exit 2
}

GETOPT_COMMAND=""

export IS_MAC="false"
export IS_LINUX="false"
if [[ "$(uname -s)" == "Darwin" ]]; then
	IS_MAC="true"
else
	IS_LINUX="true"
fi

SHELL_USED=$(ps -p $$ | tail -1 | awk '{ print $4 }' | cut -d "-" -f 2 | tail -1)
if [[ "${SHELL_USED}" != "bash" ]]; then
	export LOG_FILE=/dev/null
	if [[ "$(uname -s)" == "Darwin" ]]; then
		log_console_error "Shell in use is not Bash ('${SHELL_USED}'). Please switch to Bash v4+ for example on MacOS:
	$ brew install bash
	$ sudo bash -c 'echo /usr/local/Cellar/bash/5.0.16/bin/bash >> /etc/shells'
	$ sudo chsh -s /usr/local/Cellar/bash/5.0.16/bin/bash ${USER}"
	else
		log_console_error "Shell in use is not Bash ('${SHELL_USED}'). Please switch to Bash v4+."
	fi
	exit 2
fi

if [[ "${IS_MAC}" == "true" ]]; then
	GETOPT_COMMAND=/usr/local/opt/gnu-getopt/bin/getopt
	if [ ! -f ${GETOPT_COMMAND} ]; then
		export LOG_FILE=/dev/null
		log_console_error "'gnu-getopt' not found. Please make sure it is installed for example on MacOS:
	$ brew install gnu-getopt"
		exit 2
	fi
else
	GETOPT_COMMAND=getopt
fi

printf "${ORANGE}%s" ''
if ! params="$(
	"${GETOPT_COMMAND}" \
		-o hbd:apwfxog:reylsmivt:cz \
		-l help,debug,pre-analysis,package-discovery,tax,wamt,fsb,owasp,csa,all,app-group:,include-packages:,exclude-packages:,languages,scancode,pmd,mai,reports,report,version,zip,cf,import-dir: \
		--name "$(basename "${0}")" \
		-- \
		"${@}"
)"; then
	echo -e "${NC}"
	usage
fi
printf "${NC}%s" ''

eval set -- "${params}"
unset params

export UNPACK_ACTIVE="false"
export UNPACK_SOURCE="false"
export CSA_ACTIVE="false"
export WAMT_ACTIVE="false"
export PRE_ANALYSIS_ACTIVE="false"
export WINDUP_PACKAGE_DISCOVERY_ACTIVE="false"
export WINDUP_ACTIVE="false"
export OWASP_ACTIVE="false"
export FSB_ACTIVE="false"
export REPORT_ACTIVE="false"
export LANGUAGES_ACTIVE="false"
export SCANCODE_ACTIVE="false"
export PMD_ACTIVE="false"
export MAI_ACTIVE="false"
export VERSION_ACTIVE="false"
export PACKAGE_CF="false"
export PACKAGE_ZIP="false"

export WINDUP_INCLUDE_PACKAGES_FILE=""
export WINDUP_EXCLUDE_PACKAGES_FILE=""
export TARGET_GROUP=""
export IMPORT_DIR=""
export DEBUG=""

while true; do
	case ${1} in
	-p | --csa)
		CSA_ACTIVE="true"
		UNPACK_ACTIVE="true"
		shift
		;;
	-e | --pre-analysis)
		PRE_ANALYSIS_ACTIVE="true"
		WINDUP_PACKAGE_DISCOVERY_ACTIVE="true"
		shift
		;;
	-y | --package-discovery)
		WINDUP_PACKAGE_DISCOVERY_ACTIVE="true"
		shift
		;;
	-x | --tax)
		WINDUP_ACTIVE="true"
		UNPACK_SOURCE="true"
		shift
		;;
	--include-packages)
		WINDUP_INCLUDE_PACKAGES_FILE="${2}"
		shift 2
		;;
	--exclude-packages)
		WINDUP_EXCLUDE_PACKAGES_FILE="${2}"
		shift 2
		;;
	-w | --wamt)
		WAMT_ACTIVE="true"
		shift
		;;
	-f | --fsb)
		FSB_ACTIVE="true"
		shift
		;;
	-o | --owasp)
		OWASP_ACTIVE="true"
		shift
		;;
	-a | --all)
		UNPACK_ACTIVE="true"
		CSA_ACTIVE="true"
		WINDUP_PACKAGE_DISCOVERY_ACTIVE="true"
		WINDUP_ACTIVE="true"
		WAMT_ACTIVE="true"
		OWASP_ACTIVE="true"
		FSB_ACTIVE="true"
		SCANCODE_ACTIVE="true"
		PMD_ACTIVE="true"
		LANGUAGES_ACTIVE="true"
		MAI_ACTIVE="true"
		shift
		;;
	-r | --reports | --report)
		REPORT_ACTIVE="true"
		shift
		;;
	-l | --languages)
		LANGUAGES_ACTIVE="true"
		UNPACK_ACTIVE="true"
		shift
		;;
	-s | --scancode)
		SCANCODE_ACTIVE="true"
		UNPACK_ACTIVE="true"
		shift
		;;
	-m | --pmd)
		PMD_ACTIVE="true"
		UNPACK_ACTIVE="true"
		shift
		;;
	-i | --mai)
		MAI_ACTIVE="true"
		UNPACK_ACTIVE="true"
		shift
		;;
	-t)
		TIMESTAMP="${2}"
		shift 2
		;;
	-g | --app-group)
		TARGET_GROUP="${2}"
		shift 2
		;;
	-d | --import-dir)
		IMPORT_DIR="${2}"
		shift 2
		;;
	-b | --debug)
		DEBUG="true"
		shift
		;;
	-z | --zip)
		PACKAGE_ZIP="true"
		shift
		;;
	-c | --cf)
		PACKAGE_CF="true"
		shift
		;;
	-v | --version)
		VERSION_ACTIVE="true"
		break
		;;
	-h | --help)
		usage
		;;
	--)
		shift
		break
		;;
	*)
		usage
		;;
	esac
done

if [[ "${VERSION_ACTIVE}" == "true" ]]; then
	echo -e "${BOLD}Application Report Generator v.${TOOL_VERSION}${NORMAL}"
	echo -e "-> CSA v.${CSA_VERSION}"
	echo -e "-> TAX v.${TAX_VERSION_SHORT}"
	echo -e "-> WAMT v.${WAMT_VERSION}"
	echo -e "-> Linguist v.${LINGUIST_VERSION}"
	echo -e "-> CLOC v.${CLOC_VERSION}"
	echo -e "-> Scancode v.${SCANCODE_VERSION_DYNAMIC}"
	echo -e "-> PMD v.${PMD_VERSION}"
	echo -e "-> Microsoft Application Inspector v.${MAI_VERSION}"
	echo -e "-> OWASP Dependency-Check v.${OWASP_DC_VERSION}"
	echo -e "-> Find Security Bug v.${FSB_VERSION}"
	exit
fi

if [[ "${REPORT_ACTIVE}" == "false" && \
	"${CSA_ACTIVE}" == "false" && \
	"${PRE_ANALYSIS_ACTIVE}" == "false" && \
	"${WINDUP_PACKAGE_DISCOVERY_ACTIVE}" == "false" && \
	"${WINDUP_ACTIVE}" == "false" && \
	"${WAMT_ACTIVE}" == "false" && \
	"${OWASP_ACTIVE}" == "false" && \
	"${FSB_ACTIVE}" == "false" && \
	"${LANGUAGES_ACTIVE}" == "false" && \
	"${SCANCODE_ACTIVE}" == "false" && \
	"${PMD_ACTIVE}" == "false" && \
	"${MAI_ACTIVE}" == "false" ]]; then
	echo -e "${ORANGE}No active tool - please select at least one!${NC}"
	echo ""
	usage
fi

if [[ ! $TIMESTAMP =~ ^[0-9]{4}_[0-1][0-9]_[0-3][0-9]__[0-2][0-9]_[0-5][0-9]_[0-9]{2}$ ]]; then
	echo -e "${ORANGE}Invalid timestamp used! It should look like: $(date +%Y_%m_%d__%H_%M_%S)${NC}"
	exit 2
fi

[[ "${DEBUG}" == "true" ]] && set -x

SCRIPTS=(
	# Check prerequisites for running the tools
	00__check_prereqs.sh

	# Unpack all tools from 'dist' to 'bin'
	00__unpack_all_tools.sh

	# Verify additional prerequisites on unpacked tools
	00__verify_prereqs.sh

	# Identify apps, generate execution plans and warnings
	00__weave_execution_plan.sh
)

# Unpack with Fernflower
[[ "${UNPACK_ACTIVE}" == "true" || "${PRE_ANALYSIS_ACTIVE}" == "true" ]] && { SCRIPTS+=(01__fernflower_decompile.sh); }

# Unpack source code
[[ "${UNPACK_ACTIVE}" == "true" || "${UNPACK_SOURCE}" == "true" ]] && { SCRIPTS+=(01__unpack_sources.sh); }

# Cloud Suitability Analyzer
[[ "${CSA_ACTIVE}" == "true" ]] && { SCRIPTS+=(02__csa__01__analysis.sh 02__csa__02__extract.sh); }

# Windup - Package Discovery (TAX or RHAMT)
[[ "${WINDUP_PACKAGE_DISCOVERY_ACTIVE}" == "true" ]] && { SCRIPTS+=(03__windup__01__package_discovery.sh); }

# Windup - Package Discovery (TAX or RHAMT) - Analysis
[[ "${WINDUP_ACTIVE}" == "true" ]] && { SCRIPTS+=(03__windup__02__analysis.sh 03__windup__03__extract.sh); }

# IBM WebSphere Application Migration Toolkit
[[ "${WAMT_ACTIVE}" == "true" ]] && { SCRIPTS+=(04__wamt__01__analysis.sh 04__wamt__02__extract.sh); }

# Open Web Application Security Project - Dependency Check
[[ "${OWASP_ACTIVE}" == "true" ]] && { SCRIPTS+=(05__owasp_dc__01__analysis.sh 05__owasp_dc__02__extract.sh); }

# Scancode analysis
[[ "${SCANCODE_ACTIVE}" == "true" ]] && { SCRIPTS+=(06__scancode__analysis.sh); }

# PMD code analysis
[[ "${PMD_ACTIVE}" == "true" ]] && { SCRIPTS+=(07__pmd__01__analysis.sh 07__pmd__02__extract.sh); }

# Linguist code analysis
[[ "${LANGUAGES_ACTIVE}" == "true" ]] && { SCRIPTS+=(08__linguist_and_cloc__01__analysis.sh 08__linguist_and_cloc__02__extract.sh); }

# FindSecBugs (SpotBugs engine) code analysis
[[ "${FSB_ACTIVE}" == "true" ]] && { SCRIPTS+=(09__findsecbugs__01__analysis.sh 09__findsecbugs__02__extract.sh); }

# Microsoft Application Inspector analysis
[[ "${MAI_ACTIVE}" == "true" ]] && { SCRIPTS+=(10__mai__analysis.sh); }

# Re-extract all results
# { SCRIPTS+=(02__csa__02__extract.sh 03__windup__03__extract.sh 04__wamt__02__extract.sh 05__owasp_dc__02__extract.sh 07__pmd__02__extract.sh 08__linguist_and_cloc__02__extract.sh 09__findsecbugs__02__extract.sh); }

# Generates and package summary report with links
[[ "${PRE_ANALYSIS_ACTIVE}" == "false" ]] && { SCRIPTS+=(98__generate_link_reports.sh 99__package_reports.sh); }

# Directory containing all generated reports
REPORTS_DIR=${CURRENT_DIR}/reports/${TIMESTAMP}

if [[ -n "${IMPORT_DIR}" ]]; then
	TARGET_GROUP=$(basename "${IMPORT_DIR}")
fi

# Include name of the app group if single group is selected
if [[ "${TARGET_GROUP}" != "" ]]; then
	REPORTS_DIR=${REPORTS_DIR}__${TARGET_GROUP}
fi

mkdir -p "${REPORTS_DIR}"

# Logging
export RUN_LOG=${REPORTS_DIR}/run.log

for SCRIPT in "${SCRIPTS[@]}"; do
	log_tool_start "${SCRIPT}"
	# shellcheck source=/dev/null
	source "${SCRIPT}" 2>&1 | tee -a "${RUN_LOG}"
	if [ "${PIPESTATUS[0]}" -ne 0 ]; then exit; fi
	log_tool_end "${SCRIPT}"
done
