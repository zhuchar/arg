#!/usr/bin/env bash
# This script extracts warnings counts out of the generated FindSecurityBugs reports.

# ------ Do not modify
VERSION="${FSB_VERSION}"
STEP=$(get_step)
APP_DIR_OUT="${REPORTS_DIR}/${STEP}__FindSecBugs__${VERSION}"
export LOG_FILE="${APP_DIR_OUT}".log

SEPARATOR=","

function generate_csv() {
	GROUP=$(basename "${1}")
	log_analysis_message "group '${GROUP}'"

	RESULT_FILE="${APP_DIR_OUT}/${GROUP}___results_extracted.csv"
	rm -f "${RESULT_FILE}"

	echo "Applications${SEPARATOR}Low FS bugs${SEPARATOR}Medium FS bugs${SEPARATOR}High FS bugs${SEPARATOR}Total FS bugs" >>"${RESULT_FILE}"

	while read -r APP_FILE; do
		APP="$(basename "${APP_FILE}")"
		#log_analysis_message "app '${APP}'"

		FILE="${APP_DIR_OUT}/${GROUP}__${APP}.html"

		COUNT_HIGH=''
		COUNT_MED=''
		COUNT_LOW=''

		if [[ -f "${FILE}" ]]; then
			if [[ -s "${FILE}" ]]; then
				# Tough cleanup to prevent issues with xmllint
				TMP_FILE="${FILE}.tmp"
				echo "<html><body>" >"${TMP_FILE}"
				sed -n '/<table width="500" cellpadding="5" cellspacing="2">*/,/<\/table>/p' "${FILE}" >>"${TMP_FILE}"
				echo "</body></html>" >>"${TMP_FILE}"

				# Not needed anymore
				#sed <"${FILE}" -e "s/xmlns=\"[^\"]*\"//g" | sed -e "s/<[\/ ]*p[^>]*>//g" | sed -e "s/<[\/ ]*br[\/ ]*>//g" | sed -e "s/<[\/ ]*pre[\/ ]*>//g" | sed -e "s/&//g" | sed -e "s/<%//g" | sed -e "s/%>//g" >"${TMP_FILE}"

				COUNT_HIGH=$(xmllint --xpath 'string(/html/body/table[1]/tr[2]/td[2])' "${TMP_FILE}" | tr -d '\n' | tr -d ' ')
				COUNT_MED=$(xmllint --xpath 'string(/html/body/table[1]/tr[3]/td[2])' "${TMP_FILE}" | tr -d '\n' | tr -d ' ')
				COUNT_LOW=$(xmllint --xpath 'string(/html/body/table[1]/tr[4]/td[2])' "${TMP_FILE}" | tr -d '\n' | tr -d ' ')

				rm -f "${TMP_FILE}"
			fi

			[[ -z "${COUNT_HIGH}" || -e "${COUNT_HIGH}" ]] && COUNT_HIGH=0
			[[ -z "${COUNT_MED}" || -e "${COUNT_MED}" ]] && COUNT_MED=0
			[[ -z "${COUNT_LOW}" || -e "${COUNT_LOW}" ]] && COUNT_LOW=0
			COUNT_TOTAL=$((COUNT_HIGH + COUNT_MED + COUNT_LOW))
			echo "${APP}${SEPARATOR}${COUNT_LOW}${SEPARATOR}${COUNT_MED}${SEPARATOR}${COUNT_HIGH}${SEPARATOR}${COUNT_TOTAL##*( )}" >>"${RESULT_FILE}"
		else
			echo "${APP}${SEPARATOR}n/a${SEPARATOR}n/a${SEPARATOR}n/a${SEPARATOR}n/a" >>"${RESULT_FILE}"
		fi

	done <"${REPORTS_DIR}/list__${GROUP}__all_apps.txt"

	log_console_success "Results: ${RESULT_FILE}"
}

function main() {
	if [[ -d "${APP_DIR_OUT}" ]]; then
		for_each_group generate_csv
	else
		log_console_error "FindSecBugs missing directory: ${APP_DIR_OUT}"
	fi
}

main
