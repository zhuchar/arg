# Application Report Generator

`App-report-gen` helps teams to analyze a wide set of applications (Java, Python, .NET ...) using up to 10 analysis tools. 

## Features

This project consists of a set of utility shell scripts automating the analysis of many Java, .NET, Python ... applications by a set of tools. The scripts have been developed to run on a Linux / Unix / MacOS environment.

### Comprehensive CLI

`App-report-gen` aims at lowering the barriers to analyze a large set of applications. Your starting point is the `run.sh` Command Line Interface. It provides many options to do exactly what you want.

### Solid by default

A heavy validation is done before any analysis work to make sure that your setup fulfills all pre-requisite for the tools you want to run. All analysis tools used have also been hardened from a stability perspective. They are pre-configured using best-practices and defaults you very likely want.

### Multiple tools

`App-report-gen` bundles 10 tools analyzing your applications from 6 different perspectives: cloud-readiness, security, languages used, licensing, and quality.

![Tools 01](https://user-images.githubusercontent.com/2445024/92568471-86873e00-f27f-11ea-8fb4-8c4e0102ee96.png)

![Tools 02](https://user-images.githubusercontent.com/2445024/92568479-89822e80-f27f-11ea-8893-ad1de952b5eb.png)

### Aggregated views

`App-report-gen` generates simple static HTML pages connecting all results from the analysis tools. It also provides aggregated perspectives on:

* Cloud-readiness ([CSA](https://github.com/pivotal/pivotal-app-analyzer) + [TAX](https://github.com/pivotal/pax) + [WAMT](https://developer.ibm.com/wasdev/downloads/#asset/tools-Migration_Toolkit_for_Application_Binaries))

<img width="600" alt="Cloud" src="https://user-images.githubusercontent.com/2445024/92568480-8a1ac500-f27f-11ea-960d-a08f90a6dcb4.png">

* Security ([OWASP Dependency-Check](https://www.owasp.org/index.php/OWASP_Dependency_Check) + [Find Security Bugs](https://find-sec-bugs.github.io/))

<img width="600" alt="Security" src="https://user-images.githubusercontent.com/2445024/92568484-8ab35b80-f27f-11ea-9b7a-b24719238b9a.png">

* Quality ([PMD](https://pmd.github.io/))

<img width="600" alt="Languages" src="https://user-images.githubusercontent.com/2445024/92568485-8b4bf200-f27f-11ea-9f4c-078581bc446a.png">

* Distribution of languages ([GitHub Linguist](https://github.com/github/linguist) + [CLOC](https://github.com/AlDanial/cloc))

<img width="600" alt="Languages" src="https://user-images.githubusercontent.com/2445024/92568481-8ab35b80-f27f-11ea-9924-343e3deef3dd.png">

### More? 

Please check out [this presentation](https://docs.google.com/presentation/d/1cqlymXZBtmRY-vReK5nBgIM6-Dcn5OTm7UkziEVdFuQ/edit) (Google Slides) for more information on the single tools used, and how to tune the report generation and join the [#app-report-generator](https://vmware.slack.com/archives/C01APU19BJM) channel on Slack.

## Quick start

To analyze your applications, please follow those steps:

1. Download and unzip locally the latest `app-report-gen.zip` [distribution](https://via.vmw.com/arg-release).

1. Ensure all required tools are installed and properly configured on your machine by executing `$ cd util/01__setup/` and (CentOS/Fedora/RHEL) `$ ./setup_centos.sh` or (MacOS) `$ ./setup_macos.sh`

1. Copy and group your applications (e.g. Java binaries, zipped application source code, plain code directories) to be analysed in sub-folders of `apps`. For example in `apps/group1`.

1. Start it with `$ ./run.sh -a -g group1`

:warning: You likely will have one or several errors to fix after the pre-requisites validation. Just fix your setup and restart the analysis with the same command (`$ ./run.sh -a`). Validations are tough to ensure a stable run of all tools once you started an execution.

1. Open the `index.html` file within the created `reports/TIMESTAMP` directory.

1. Have fun exploring the reports and tool [capabilities](https://docs.google.com/presentation/d/1cqlymXZBtmRY-vReK5nBgIM6-Dcn5OTm7UkziEVdFuQ/edit)!


## Prerequisites

The scripts have been developed to run on a Linux / Unix / MacOS environment. They require several tools and services to be properly installed and configured. 

### Automated setup

After downloading and unpacking the [latest release](https://via.vmw.com/arg-release), you should just run the setup script matching your OS:

    $ cd util/01__setup/
    # For CentOS / Fedora / RHEL
    $ ./setup_centos.sh
    # For MacOS
    $ ./setup_macos.sh

### Manual setup

As alternativem, you can follow those instructions to configure the prerequisites on your MacBook. You will need ...

* a terminal (like iTerm) and bash **4** or later properly installed (MacOS defaults to Bash 3).

Otherwise, install [brew](https://brew.sh/) and execute:

    $ brew cask install iterm2
    $ brew install bash

* an installed Java (Open/AdoptOpen) JDK 11 and neither below nor above

This can be easily checked by executing `$ java --version`. If you have no Java JDK 11 installed, you should consider installing SDKman following [those instructions](https://sdkman.io/install). Then install Java AdoptOpenJDK 11.0.5 by executing:

    $ sdk install java 11.0.6.hs-adpt

* to make sure that your setting max open files is greater than 100.000 (check by executing `$ ulimit -n`).

Otherwise, execute:

    $ ./util/set_ulimit.sh

* several additional standard Linux / Unix utilities (`sha1sum`, `jq`, `xmllint`, `gnu-getopt`).

Those could be installed with the following command:

    $ brew install md5sha1sum jq libxml2 gnu-getopt

* a running docker environment if you wish to do a GitHub Linguist source code analysis.

This can be installed and then started as follows on MacOS:

    $ brew cask install docker
    $ open /Applications/Docker.app

* a dotnet 3.1 environment if you wish to use the Microsoft Application Inspector.

This can be installed and then started as follows on MacOS:

    # Install .NET 5
    $ brew cask install dotnet-sdk

    # Install .NET 3.1
    $ brew tap isen-ng/dotnet-sdk-versions; brew install --cask dotnet-sdk3-1-400


## Usage

```
./run.sh -h
usage: run.sh   [-d | --import-dir <dir>] [-g | --app-group <name>] [-a | --all] [-p | --csa]
                [-x | --tax] [--include-packages <file>] [--exclude-packages <file>] [-w | --wamt] [-o | --owasp]
                [-f | --fsb] [-l | --languages] [-s | --scancode] [-m | --pmd] [-y | --package-discovery]
                [-b | --debug] [-r | --reports] [-e | --pre-analysis] [-t | --timestamp] [-v | --version] [-h | --help]

SELECT APPS  -----------------------------------------------------------------------------------------------
              -d, --import-dir <dir>         Import and analyze apps in <dir> (sub-folder of 'apps')
              -g, --app-group <name>         Analyze only the apps in the group <name> (sub-folder of 'apps')

SELECT TOOLS  ----------------------------------------------------------------------------------------------
  General     -a, --all                      Run all available tools (-pxwoflsm)

  Cloud       -p, --csa                      Decompile and run the CSA analysis
              -x, --tax                      Run the Tanzu Application eXplorer (TAX) tool
                 --include-packages <file>   File containing Java packages to include in TAX analysis
                 --exclude-packages <file>   File containing Java packages to exclude from TAX analysis
              -w, --wamt                     Run the WebSphere Application Server Migration Toolkit analysis

  Security    -o, --owasp                    Run the OWASP Dependency Check analysis
              -f, --fsb                      Decompile and run the FindSecBugs analysis

  Languages   -l, --languages                Decompile and run the Linguist and CLOC analysis

  Licensing   -s, --scancode                 Decompile and run the ScanCode analysis

  Quality     -m, --pmd                      Decompile and run the PMD Code analysis
              -i, --mai                      Decompile and run the Microsoft Application Inspector analysis

REPORTING  -----------------------------------------------------------------------------------------------
              -z, --zip                      Zip the generated reports
              -c, --cf                       Package the generated reports for cloud foundry deployment
              -r, --reports                  Re-generate the HTML reports
              -t <timestamp>                 Set a timestamp for the analysis (e.g. 2020_09_08__10_48_29)

ADVANCED  ------------------------------------------------------------------------------------------------
              -e, --pre-analysis             Run a pre-configuration analysis
              -y, --package-discovery        Run the TAX package discovery. Used to configure a TAX analysis
              -b, --debug                    Enable debug mode
              -v, --version                  Display the version numbers
              -h, --help                     Show this help message
```

## Some examples

`$ ./run.sh -h`: Provide **h**elp by showing all available CLI options.

`$ ./run.sh -a`: Decompile and run **a**ll tools (CSA, TAX, WAMT, OWASP DC, FSB, Linguist, CLOC, Scancode, PMD, MAI) to analyze all apps in the `apps` sub-folders.

`$ ./run.sh -a -d /my/apps`: Import, decompile, and run **a**ll tools to analyze only the apps in the `/my/apps` folder.

`$ ./run.sh -a -g small`: Decompile and run **a**ll tools to analyze only the apps in the `small` **g**roup ( subfolder of `apps` -> `apps/small`)

`$ ./run.sh -x`: Run Tanzu Application e**X**plorer (TAX) to analyze all apps in the `apps` sub-folders.

`$ ./run.sh -p -x -o`: Decompile and run **P**AA, PA**X**, and **O**WASP DC to analyze all apps in the `apps` sub-folders.

`$ ./run.sh -e`: Conduct a pr**e**-configudation analysis to discover libraries and packages that could be excluded from the analysis.

## Inventory

**Scripts**

* `00__check_prereqs.sh`: Check that the prerequisites to run the tools are met. 
* `00__unpack_all_tools.sh`: Unpack all downloaded tools from `dist` to `bin`.
* `00__verify_prereqs.sh`: Validate further prerequisites to runs the tools.
* `00__weave_execution_plan.sh`: Identify application types, generate tool execution plans.
* `01__fernflower_decompile.sh`: Recursively unpack apps and decompiles relevant libraries using Fernflower.
* `01__unpack_sources.sh`: Unpack zipped application code and copy source code folders.
* `02__csa__01__analysis.sh`: Analysis of all applications using Tanzu Cloud Suitability Analyzer (CSA).
* `02__csa__02__extract.sh`: Extract the Tanzu Cloud Suitability Analyzer (CSA) results to a CSV file.
* `03__windup__01__package_discovery.sh`: Analysis of all Java binary applications to discover the used package using Windup.
* `03__windup__02__analysis.sh`: Analysis of all Java binary applications using Windup (TAX or RHAMT).
* `03__windup__03__extract.sh`: Extract the Windup analysis results to a CSV file.
* `04__wamt__01__analysis.sh`: Analysis of all Java binary applications using WAMT.
* `04__wamt__02__extract.sh`: Extract the WAMT results to a CSV file.
* `05__owasp_dc__01__analysis.sh`: Analysis of all applications using OWASP Dependency Check.
* `05__owasp_dc__02__extract.sh`: Extract the OWASP Dependency Check analysis results to a CSV file.
* `06__scancode__analysis.sh`: Analysis of all applications using ScanCode Toolkit.
* `07__pmd__01__analysis.sh`: Analysis of all Java applications using PMD source code analyzer.
* `07__pmd__02__extract.sh`: Extract the PMD results to a CSV file.
* `08__linguist_and_cloc__01__analysis.sh`: Identification of the used languages using CLOC and GitHub Linguist.
* `08__linguist_and_cloc__02__extract.sh`: Extract the language analysis results.
* `09__findsecbugs__01__analysis.sh`: Analysis of all Java applications using Find Security Bugs.
* `09__findsecbugs__02__extract.sh`: Extract the Find Security Bugs analysis results to a CSV file.
* `10__mai__analysis.sh`: Analysis of all applications using Microsoft Application Inspector.
* `98__generate_link_reports.sh`: Generate HTML reports linking all generated results.
* `99__package_reports.sh`: Package resulting reports as a zip file or for cloud-foundry deployment.
* `_shared_functions.sh`: Shared functions used by many other scripts.
* `_versions.sh`: Versions in use of each tool.
* `run.sh`: Chains the analysis.

**Sub-directories** 

* `apps`: Contains all applications to be analyzed. Apps have to be grouped in subfolders or imported using the "-d" or "--import-dir" option. Subfolders are analysed separately.

Example:
```
apps
├── group-1
│   ├── app1.ear
│   ├── app2.war
│   └── app3.zip
└── group-2
    ├── app4.jar
    └── app5_dir
```

* `bin`: Contains all unpacked and configured analysis tools.
* `conf`: Contains the configuration for every tool in use.
* `dist`: Contains the installation distributions of the tools.
* `reports`:  Centralises all reports and results generated  by the analysis tools.
* `util`: Contains utility scripts to update and cleanup tools and scripts.

Example of a plain-default report:
```
reports
└── 2020_09_09__10_49_36
    ├── 01__Fernflower__2019.29.12.log
    ├── 01__Fernflower__all_libs.txt
    ├── 01__Fernflower__unpacked_libs_SHA1.txt
    ├── 01__Fernflower__unpacked_libs.txt
    ├── 01__unpack_sources.log
    ├── 02__CSA__3.1.0-rc1
    ├── 02__CSA__3.1.0-rc1.log
    ├── 02__CSA__3.1.0-rc1__results_extracted.csv
    ├── 02__CSA__3.1.0-rc1__results_extracted_bagger.csv
    ├── 02__CSA__3.1.0-rc1__results_missing.csv
    ├── 03__TAX__4.3.1.Final__packages
    ├── 03__TAX__4.3.1.Final__packages.log
    ├── 03__TAX__4.3.1.Final__results_extracted.csv
    ├── 03__small__TAX__4.3.1.Final
    ├── 03__small__TAX__4.3.1.Final.log
    ├── 03__small__TAX__4.3.1.Final__results_extracted.csv
    ├── 04__WAMT__20.0.0.3
    ├── 04__WAMT__20.0.0.3.log
    ├── 05__small__OWASP_DC__5.3.2
    ├── 05__small__OWASP_DC__5.3.2.log
    ├── 06__SCANCODE__3.0.2.log
    ├── 06__small__SCANCODE__3.0.2
    ├── 07__PMD__6.27.0
    ├── 07__PMD__6.27.0.log
    ├── 08__LINGUIST__7.10.0
    ├── 08__LINGUIST__7.10.0.log
    ├── 08__LOC__CLOC__results_extracted.csv
    ├── 08__LOC__LINGUIST__results_extracted.csv
    ├── 09__FindSecBugs__1.10.1
    ├── 09__FindSecBugs__1.10.1.log
    ├── 10__MAI__1.2.59
    ├── 10__MAI__1.2.59.log
    ├── cloud.html
    ├── index.html          <== Starting point to explore the results !
    ├── languages.html
    ├── launch_csa_ui.sh    <== Script to start the CSA UI
    ├── quality.html
    ├── run.log
    ├── security.html
    └── static
```
