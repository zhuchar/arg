#!/usr/bin/env bash
# This script extracts results out of the generated CSA database file.

STEP=$(get_step)
SEPARATOR=","
S="${SEPARATOR}"
APP_DIR_OUT="${REPORTS_DIR}/${STEP}__CSA__${CSA_VERSION}"
DB_LOCATION="${APP_DIR_OUT}/csa.db"
MISSING_FILE="${APP_DIR_OUT}__results_missing.csv"
RESULT_BAGGER_FILE="${APP_DIR_OUT}__results_extracted_bagger.csv"
RESULT_FILE="${APP_DIR_OUT}__results_extracted.csv"
export LOG_FILE=/dev/null

function check_missing_apps() {
	GROUP_DIR=${1}
	GROUP=$(basename "${GROUP_DIR}")

	log_analysis_message "group '${GROUP}'"

	while read -r FILE; do
		APP="$(basename "${FILE}")"
		if [[ -f "${RESULT_BAGGER_FILE}" ]]; then
			if ! grep -q "${GROUP}${S}${APP}${S}" "${RESULT_BAGGER_FILE}"; then
				echo "${GROUP}${S}${APP}${S}${APP}${S}n/a${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}" >>"${MISSING_FILE}"
			fi
		else
			echo "${GROUP}${S}${APP}${S}${APP}${S}n/a${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}${S}" >>"${MISSING_FILE}"
		fi
	done <"${REPORTS_DIR}/list__${GROUP}__all_apps.txt"
}

function main() {
	# Extract results using bagger
	rm -f "${RESULT_BAGGER_FILE}"
	if [[ -f "${DB_LOCATION}" ]]; then
		java -jar "${INSTALL_DIR}"/bagger*.jar "${DB_LOCATION}" "${RESULT_BAGGER_FILE}" "${S}"
	else
		log_console_error "CSA database file does not exist: ${DB_LOCATION}"
		exit
	fi

	# Check missing entries
	rm -f "${MISSING_FILE}"
	for_each_group check_missing_apps

	# Add missing entries
	touch "${RESULT_BAGGER_FILE}" "${MISSING_FILE}"
	cat "${RESULT_BAGGER_FILE}" "${MISSING_FILE}" | sort | uniq >"${RESULT_FILE}"

	# FIXME: Issue with cat if the next line in uncommented.
	#rm -f "${RESULT_BAGGER_FILE}" "${MISSING_FILE}";
}

main
