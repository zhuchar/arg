#!/usr/bin/env bash
#set -x

##############################################################################################################
# OWASP DC (Open Web Application Security Project Dependency Check)
# https://www.owasp.org/index.php/OWASP_Dependency_Check
#
# This script analyzes all binary applications (EAR/WAR/JAR) in ${APP_DIR_IN} grouped in sub-folders.
##############################################################################################################

# ----- Please adjust

# Uses the locally cached NVD and RetireJs databases (in ${CACHE_DIR}). No update is done automatically.
USE_LOCAL_CACHE="true"

# Sets whether the Central Analyzer will be used. Disabling this analyzer is not recommended as it could lead to false negatives (e.g. libraries that have vulnerabilities may not be reported correctly).
DISABLE_CENTRAL_REPO="true"

# Sets whether to use the experimental Python scanner.
ENABLE_PYTHON_SCANNING="false"

# Generate verbose log for each application
ENABLE_VERBOSE_LOG="false"

# ------ Do not modify
DC_DIR=${INSTALL_DIR}/dependency-check/bin
VERSION=${OWASP_DC_VERSION}
STEP=$(get_step)

CACHE_DIR="${DIST_DIR}/owasp_cache"
NVD="file://${CACHE_DIR}/NVD"

# Base URL for each year’s CVE JSON data feed, the %d will be replaced with the year. (https://nvd.nist.gov/feeds/json/cve/1.1/nvdcve-1.1-%d.json.gz)
CVE_URL_BASE="${NVD}/nvdcve-1.1-%d.json.gz"

# URL for the modified CVE JSON data feed. When mirroring the NVD you must mirror the *.json.gz and the *.meta files. (https://nvd.nist.gov/feeds/json/cve/1.1/nvdcve-1.1-modified.json.gz)
CVE_URL_MODIFIED="${NVD}/nvdcve-1.1-modified.json.gz"

# The URL to the Retire JS repository. Note the file name must be jsrepository.json.
RETIRE_JS_URL="file://${CACHE_DIR}/jsrepository.json"

# Analyse all applications present in the ${1} directory.
function analyze() {
	APP_DIR_INCOMING=${1}
	GROUP=$(basename "${APP_DIR_INCOMING}")
	APP_DIR_OUT=${REPORTS_DIR}/${STEP}__${GROUP}__OWASP_DC__${VERSION}
	LOG_FILE=${APP_DIR_OUT}.log

	mkdir -p "${APP_DIR_OUT}"
	log_analysis_message "group '${GROUP}'"

	while read -r APP; do
		APP_NAME=$(basename "${APP}")
		# OWASP DC arguments
		ARGS=(
			--project "[${GROUP}] ${APP_NAME}"
			-f ALL
			--out "${APP_DIR_OUT}"
			--scan "${APP}"
			--disableBundleAudit
			--disableRubygems
			--disableCocoapodsAnalyzer
		)
		[[ "${ENABLE_VERBOSE_LOG}" == "true" ]] && ARGS+=(-l "${APP_DIR_OUT}__${APP_NAME}.log")
		[[ "${DISABLE_CENTRAL_REPO}" == "true" ]] && ARGS+=(--disableCentral)
		[[ "${USE_LOCAL_CACHE}" == "true" ]] && ARGS+=(--cveUrlModified "${CVE_URL_MODIFIED}" --cveUrlBase "${CVE_URL_BASE}" --retireJsUrl "${RETIRE_JS_URL}")
		[[ "${ENABLE_PYTHON_SCANNING}" == "true" ]] && {
			ARGS+=(--enableExperimental)
			ARGS+=(--disablePyDist "false")
			ARGS+=(--disablePyPkg "false")
		}

		set +e
		(time bash "${DC_DIR}"/dependency-check.sh "${ARGS[@]}") >>"${LOG_FILE}" 2>&1
		set -e

		if [[ -f "${APP_DIR_OUT}/dependency-check-junit.xml" ]]; then
			mv "${APP_DIR_OUT}/dependency-check-junit.xml" "${APP_DIR_OUT}/${APP_NAME}_dc_junit.xml"
			mv "${APP_DIR_OUT}/dependency-check-report.csv" "${APP_DIR_OUT}/${APP_NAME}_dc_report.csv"
			mv "${APP_DIR_OUT}/dependency-check-report.html" "${APP_DIR_OUT}/${APP_NAME}_dc_report.html"
			mv "${APP_DIR_OUT}/dependency-check-report.json" "${APP_DIR_OUT}/${APP_NAME}_dc_report.json"
			mv "${APP_DIR_OUT}/dependency-check-report.xml" "${APP_DIR_OUT}/${APP_NAME}_dc_report.xml"
		fi

		log_console_info "Results: ${APP_DIR_OUT}/${APP_NAME}_dc_report.html"

	done <"${REPORTS_DIR}/list__${GROUP}__owasp_dc.txt"

	log_console_success "Open this directory for all results: ${APP_DIR_OUT}"
}

function main() {
	for_each_group analyze
}

main
