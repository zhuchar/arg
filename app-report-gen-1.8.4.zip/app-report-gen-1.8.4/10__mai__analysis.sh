#!/usr/bin/env bash

##############################################################################################################
# Microsoft Application Inspector
#
# Source code analyzer built for surfacing features of interest and other characteristics to answer the question 'what's in it'
# using static analysis with a json based rules engine. Ideal for scanning components before use or detecting feature level changes.
# https://github.com/microsoft/ApplicationInspector
#
# This script analyzes all binary applications (EAR/WAR/JAR) in ${APP_DIR_IN} grouped in sub-folders.
##############################################################################################################

# ----- Please adjust

# ------ Do not modify
VERSION=${MAI_VERSION}
MAI_DIR=${INSTALL_DIR}/ApplicationInspector_netcoreapp_${VERSION}
MAI="${MAI_DIR}/ApplicationInspector.CLI.dll"
STEP=$(get_step)
APP_DIR_OUT=${REPORTS_DIR}/${STEP}__MAI__${VERSION}
export LOG_FILE=${APP_DIR_OUT}.log

# Analyse all applications present in the ${1} directory.
function analyze() {

	GROUP=$(basename "${1}")
	log_analysis_message "group '${GROUP}'"

	while read -r APP; do
		set +e
		APP_NAME=$(basename "${APP}")
		log_analysis_message "app '${APP_NAME}'"
		MAI_OUT=${APP_DIR_OUT}/mai__${GROUP}__${APP_NAME}

		if [[ -f "${APP}" || -d "${APP}" ]]; then
			pushd "${MAI_DIR}" &>/dev/null
			(time dotnet "${MAI}" analyze -s "${APP}" -b false -v Info -x high -c high,medium -k lib,.vs,.git,.idea) >>"${LOG_FILE}" 2>&1
			OUTPUT_HTML="${MAI_DIR}/output.html"
			OUTPUT_JSON="${MAI_DIR}/output.json"
			[[ -f "${OUTPUT_HTML}" ]] && mv "${OUTPUT_HTML}" "${MAI_OUT}.html"
			[[ -f "${OUTPUT_JSON}" ]] && mv "${OUTPUT_JSON}" "${MAI_OUT}.json"

			# Substitution of "output.json" by "mai__${GROUP}__${APP_NAME}.json"
			TARGET_FILE="${MAI_OUT}.html"
			if [ -f "${TARGET_FILE}" ]; then
				REGEX="s|output.json|mai__${GROUP}__${APP_NAME}.json|g"
				if [[ "${IS_MAC}" == "true" ]]; then
					sed -i '' -e "${REGEX}" "${TARGET_FILE}"
				else
					sed -i -e "${REGEX}" "${TARGET_FILE}"
				fi
			fi

			popd &>/dev/null
		fi
		set -e
	done <"${REPORTS_DIR}/list__${GROUP}__all_apps.txt"
}

function main() {
	mkdir -p "${APP_DIR_OUT}"
	if [[ -d "${MAI_DIR}/html" ]]; then
		cp -Rfp "${MAI_DIR}/html" "${APP_DIR_OUT}/."
		for_each_group analyze
		rm -f "${APP_DIR_OUT}/html/index.html"
		log_console_success "Open this directory for the results: ${APP_DIR_OUT}"
	else
		log_console_error "MAI analysis canceled. Directory not found: '${MAI_DIR}/html'"
	fi
}

main
