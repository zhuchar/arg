#!/usr/bin/env bash

##############################################################################################################
# IBM WAMT (WebSphere Application Server Migration Toolkit)
# https://www.ibm.com/developerworks/library/mw-1701-was-migration/index.html
#
# This script analyzes all EAR, WAR binary applications in ${APP_DIR_IN} grouped in sub-folders.
##############################################################################################################

# ----- Please adjust

#    --sourceAppServer=[jboss|liberty|libertyCore|other|tomcat|was61|was70|was80|was855|was90|weblogic]
#	Include rules for migrating from the specified source application server to the target application server. The default is was855.
#	The following options are valid:
#	* jboss - JBoss Application Server
#	* liberty - WebSphere Application Server Liberty
#	* libertyCore - WebSphere Application Server Liberty Core
#	* other - Other third-party servers
#	* tomcat - Apache Tomcat Application Server
#	* was61 - WebSphere Application Server traditional V6.1
#	* was70 - WebSphere Application Server traditional V7.0
#	* was80 - WebSphere Application Server traditional V8.0
#	* was855 - WebSphere Application Server traditional V8.5.5
#	* was90 - WebSphere Application Server traditional V9.0
#	* weblogic - WebLogic Application Server
SOURCE_APPLICATION_SERVER=jboss

#    --targetAppServer=[liberty|libertyCore|was855|was90]
#	Include rules for migrating to the specified target application server from the source application server. The default is liberty.
#	The following options are valid:
#	* liberty - WebSphere Application Server Liberty
#	* libertyCore - WebSphere Application Server Liberty Core
#	* was855 - WebSphere Application Server traditional V8.5.5
#	* was90 - WebSphere Application Server traditional V9.0
TARGET_APPLICATION_SERVER=libertyCore

#    --targetCloud=[containers|cfIBMCloud|thirdParty|vmIBMCloud]
#	Include rules for migrating to the specified target cloud runtime environment. There is no default. If you specify this option without
#	a source or target application server, only cloud rules are included.
#	The following options are valid:
#	* containers - Containers (IBM Cloud Pak for Applications, Kubernetes)
#	* cfIBMCloud - IBM Cloud Runtimes (CF PaaS)
#	* thirdParty - Third-party PaaS (CF)
#	* vmIBMCloud - Virtual machines (IBM Cloud)
TARGET_CLOUD=thirdParty

#    --targetJava=[ibm7|ibm8|java11|java14|oracle7|oracle8]
#	Include rules for migrating to the specified target Java version from the source Java version. The default is ibm8 for all target application server options.
#   The following options are valid:
#	* ibm7 - IBM Java 7
#	* ibm8 - IBM Java 8
#	* java11 - Java 11 (LTS)
#	* java14 - Java 14 (non-LTS)
#	* oracle7 - Oracle Java 7
#	* oracle8 - Oracle Java 8
TARGET_JAVA=java14

#    --sourceJava=[ibm5|ibm6|ibm7|ibm8|java11|java14|oracle5|oracle6|oracle7|oracle8]
#	Include rules for migrating from the specified source Java version to the target Java version. The default is ibm5 for V6.1, ibm6 for V7.0 to V8.5.5, and ibm8 for the V9.0 traditional source application server options. The default is ibm8 for all other source application
#	application server options. The following options are valid:
#	* ibm5 - IBM Java 5
#	* ibm6 - IBM Java 6
#	* ibm7 - IBM Java 7
#	* ibm8 - IBM Java 8
#	* java11 - Java 11  (LTS)
#	* java14 - Java 14 (non-LTS)
#	* oracle5 - Oracle Java 5
#	* oracle6 - Oracle Java 6
#	* oracle7 - Oracle Java 7
#	* oracle8 - Oracle Java 8
SOURCE_JAVA=ibm5

# ------ Do not modify
VERSION=${WAMT_VERSION}
WAMT_JAR=${INSTALL_DIR}/wamt/binaryAppScanner.jar
STEP=$(get_step)
APP_DIR_OUT="${REPORTS_DIR}/${STEP}__WAMT__${VERSION}"
LOG_FILE="${APP_DIR_OUT}".log

# Analyse all applications present in the ${1} directory.
function analyze() {
	GROUP=$(basename "${1}")
	APP_FOUND="false"
	JAVA_BIN_LIST="${REPORTS_DIR}/list__${GROUP}__java-bin.txt"

	log_analysis_message "group '${GROUP}'"

	while read -r APP; do
		APP_FOUND="true"
		APP_NAME=$(basename "${APP}")
		log_analysis_message "app '${APP_NAME}'"
		APP_OUT=${APP_DIR_OUT}/${GROUP}__${APP_NAME}.html
		## --sourceAppServer=was855 and --targetAppServer=liberty are the default.
		## Note: --output=${APP_OUT} cannot be specified while containing several outputs
		set +e
		(time java -Duser.language=en -jar "${WAMT_JAR}" "${APP}" --all --sourceAppServer="${SOURCE_APPLICATION_SERVER}" --targetAppServer="${TARGET_APPLICATION_SERVER}" --targetCloud="${TARGET_CLOUD}" --sourceJava="${SOURCE_JAVA}" --targetJava="${TARGET_JAVA}" --output="${APP_OUT}") >>"${LOG_FILE}" 2>&1
		set -e
	done < <(grep '.*\.[ew]ar$' "${JAVA_BIN_LIST}")

	if [[ "${APP_FOUND}" == "true" ]]; then
		log_console_success "Open this directory for the results: ${APP_DIR_OUT}"
	else
		log_console_warning "No EAR/WAR Java application found. Skipping WAMT analysis."
	fi
}

function main() {
	mkdir -p "${APP_DIR_OUT}"

	for_each_group analyze
}

main
