#!/usr/bin/env bash
#set -x

##############################################################################################################
# Optionally package the generated reports to be deployed on Cloud Foundry
#
# cf: Different descriptors are created to deploy the results on cloud-foundry.
#     In the additional created folder (named *_CF), you will find:
#     -> a 'public' directory containing the content meant to be served by an nginx instance
#     -> a 'csa' directory with a copy of the CSA database served by a sidecar binary container
##############################################################################################################

# ----- Please adjust
# Used nginx buildpack
#export NGINX_BUILDPACK="nginx_buildpack"
export NGINX_BUILDPACK="https://github.com/cloudfoundry/nginx-buildpack.git"
export CF_NAME_PREFIX="tanzu-app-report"

# ------ Do not modify
TEMPLATE_DIR=${INSTALL_DIR}/templating
TEMPLATE_DIR_CF=${TEMPLATE_DIR}/cf
MUSTACHE="${TEMPLATE_DIR}/mo"
export LOG_FILE=/dev/null
export CF_APP_NAME

function main() {

	log_console_info "Packaging the reports - CF: ${PACKAGE_CF} - ZIP: ${PACKAGE_ZIP}"

	REPORTS_DIR_CF="${REPORTS_DIR}_CF"
	REPORTS_DIR_CF_PUBLIC="${REPORTS_DIR_CF}/public"
	REPORTS_DIR_CF_CSA="${REPORTS_DIR_CF}/csa"

	if [[ "${PACKAGE_CF}" == "true" ]]; then
		rm -Rf "${REPORTS_DIR_CF}"
		mkdir -p "${REPORTS_DIR_CF_PUBLIC}" "${REPORTS_DIR_CF_CSA}"

		T=$(echo "${TIMESTAMP}" | tr '_' '-')
		if [[ "${TARGET_GROUP}" != "" ]]; then
			CF_APP_NAME="${CF_NAME_PREFIX}-${T}-${TARGET_GROUP}"
		else
			CF_APP_NAME="${CF_NAME_PREFIX}-${T}"
		fi

		cp -Rfp "${REPORTS_DIR}/" "${REPORTS_DIR_CF_PUBLIC}/."

		declare MANIFEST
		# Generate a sidecar if some CSA report has been successfully generated
		if [[ -f "${REPORTS_DIR}/02__CSA__${CSA_VERSION}/csa.db" ]]; then
			MANIFEST=manifest-all.yml.mo
			cp -fp "${INSTALL_DIR}/cloud-suitability-analyzer/csa-l" "${REPORTS_DIR_CF_CSA}/."
			cp -fp "${REPORTS_DIR}/02__CSA__${CSA_VERSION}/csa.db" "${REPORTS_DIR_CF_CSA}/."
			rm -Rf "${REPORTS_DIR_CF_PUBLIC}/02__CSA__${CSA_VERSION}"
			rm -Rf "${REPORTS_DIR_CF_PUBLIC}/launch_csa_ui.sh"
		else
			MANIFEST=manifest.yml.mo
		fi

		${MUSTACHE} "${TEMPLATE_DIR_CF}/cf-push.sh.mo" >"${REPORTS_DIR_CF}/cf-push.sh"
		${MUSTACHE} "${TEMPLATE_DIR_CF}/${MANIFEST}" >"${REPORTS_DIR_CF}/manifest.yml"
		cp -fp "${TEMPLATE_DIR_CF}/.profile" "${REPORTS_DIR_CF}"
		cp -fp "${TEMPLATE_DIR_CF}/buildpack.yml" "${REPORTS_DIR_CF}"
		cp -fp "${TEMPLATE_DIR_CF}/mime.types" "${REPORTS_DIR_CF}"
		cp -fp "${TEMPLATE_DIR_CF}/nginx.conf" "${REPORTS_DIR_CF}"

		chmod +x "${REPORTS_DIR_CF}/cf-push.sh"

		# Zip public directory
		pushd "${REPORTS_DIR_CF}" &>/dev/null
		set +e
		zip -r public.zip ./public &>/dev/null
		rm -Rf ./public
		set -e
		popd &>/dev/null

	fi

	export REPORTS REPORT_DIR_NAME

	if [[ "${PACKAGE_ZIP}" == "true" ]]; then
		if [[ "${PACKAGE_CF}" == "true" ]]; then
			REPORTS=${REPORTS_DIR_CF}
		else
			REPORTS=${REPORTS_DIR}
		fi

		REPORT_DIR_NAME=$(basename "${REPORTS}")
		pushd "${REPORTS}/.." &>/dev/null
		set +e
		rm -f "${REPORT_DIR_NAME}.zip"
		zip -r "${REPORT_DIR_NAME}.zip" "${REPORT_DIR_NAME}" &>/dev/null
		rm -Rf "${REPORTS}"
		set -e
		popd &>/dev/null
	fi

	if [[ "${PACKAGE_ZIP}" == "true" ]]; then
		FORMAT=''
		if [[ "${PACKAGE_CF}" == "true" ]]; then
			FORMAT=' as CF-deployable (cf-push.sh)'
		fi
		log_console_success "Report successfully zipped${FORMAT}: '${REPORTS}.zip'"
	else
		if [[ "${PACKAGE_CF}" == "true" ]]; then
			log_console_success "CF deployment succesfully created. Deploy by executing: 'cd ${REPORTS_DIR_CF}; ./cf-push.sh'"
		fi
	fi

	if [[ "${PACKAGE_CF}" == "true" ]]; then
		log_console_info "Depending on your running TAS instance, you might have to change the nginx buildpack in use (manifest.yml) to 'https://github.com/cloudfoundry/nginx-buildpack.git' or to 'nginx_buildpack'"
	fi
}

main
