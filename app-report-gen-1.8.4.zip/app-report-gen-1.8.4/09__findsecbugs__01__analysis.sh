#!/usr/bin/env bash

##############################################################################################################
# Find Security Bugs
# https://find-sec-bugs.github.io/
#
# This script analyzes all EAR, WAR, JAR binary applications in ${APP_DIR_IN} grouped in sub-folders.
##############################################################################################################

# ------ Do not modify
VERSION="${FSB_VERSION}"
STEP=$(get_step)
FSB="${INSTALL_DIR}/findsecbugs-cli-${VERSION}/findsecbugs.sh"

# Analyse all applications present in the ${1} directory.
function analyze() {
	GROUP=$(basename "${1}")
	log_analysis_message "group '${GROUP}'"
	LIST_JAVA_BIN="${REPORTS_DIR}/list__${GROUP}__java-bin.txt"
	if [[ -s "${LIST_JAVA_BIN}" ]]; then

		while read -r APP; do
			APP_NAME=$(basename "${APP}")
			log_analysis_message "app '${APP_NAME}'"
			APP_OUT=${APP_DIR_OUT}/${GROUP}__${APP_NAME}.html
			# Prevent crash for empty applications
			set +e
			#echo "${FSB}" -low -html -output "${APP_OUT}" "${APP}"
			(time ${FSB} -low -html -output "${APP_OUT}" "${APP}") >>"${LOG_FILE}" 2>&1
			set -e
		done <"${LIST_JAVA_BIN}"
		log_console_success "Open this directory for the results: ${APP_DIR_OUT}"

	else
		log_console_warning "No Java application found. Skipping FindSecBug analysis."
	fi
}

function main() {
	APP_DIR_OUT="${REPORTS_DIR}/${STEP}__FindSecBugs__${VERSION}"
	LOG_FILE="${APP_DIR_OUT}".log
	mkdir -p "${APP_DIR_OUT}"

	for_each_group analyze
}

main
