#!/usr/bin/env bash
#set -x

##############################################################################################################
# Generate HTML file linking all reports.
##############################################################################################################

# ----- Please adjust
export NAV_LINK="https://github.com/pivotal/app-report-gen"
export NAV_ICON="icon-github"
#export NAV_LINK="https://tanzu.vmware.com/tanzu"
#export NAV_ICON="icon-rocket"

# ------ Do not modify
TEMPLATE_DIR=${INSTALL_DIR}/templating
MUSTACHE="${TEMPLATE_DIR}/mo"
export LOG_FILE CSA_URL
LOG_FILE=/dev/null
IS_FIRST_GROUP="true"
SEPARATOR=','
if [[ "${PACKAGE_CF}" == "true" ]]; then
	CSA_URL='./csa/'
else
	CSA_URL='http://localhost:3001/'
fi
SUMMARY_CSV="${REPORTS_DIR}/99__results__all.csv"
SUMMARY_CSV_FULL_NAME="${REPORTS_DIR}/ARG__${TIMESTAMP}__all__results.csv"
CLOUD_TMP_CSV="${REPORTS_DIR}/99__results__cloud.csv"
SECURITY_TMP_CSV="${REPORTS_DIR}/99__results__security.csv"
QUALITY_TMP_CSV="${REPORTS_DIR}/99__results__quality.csv"

function export_vars() {

	export APP_GROUP APP_COUNT LANGUAGES_URL LANGUAGES_LOG RHAMT_URL RHAMT_PACKAGES RHAMT_CSV_ALL RHAMT_LOG TAX_URL TAX_PACKAGES TAX_CSV_ALL TAX_LOG WAMT_URL WAMT_LOG FSB_URL FSB_LOG ODC_URL ODC_LOG PMD_URL PMD_LOG SCANCODE_URL SCANCODE_LOG TOOLS_COUNT MAI_URL MAI_LOG HAS_TAX_PACKAGES_REPORT CSV_URL

	TOOLS_COUNT=0

	APP_GROUP=$(basename "${1}")
	APP_COUNT=$(count_lines "${REPORTS_DIR}/list__${APP_GROUP}__all_apps.txt")

	CSV_URL="./ARG__${TIMESTAMP}__all__results.csv"

	RHAMT_URL="./03__${APP_GROUP}__RHAMT__${RHAMT_VERSION}/index.html"
	RHAMT_PACKAGES="./03__RHAMT__${RHAMT_VERSION}__packages/"
	RHAMT_CSV_ALL="./03__${APP_GROUP}__RHAMT__${RHAMT_VERSION}/AllIssues.csv"
	RHAMT_LOG="./03__${APP_GROUP}__RHAMT__${RHAMT_VERSION}.log"
	TAX_URL="./03__${APP_GROUP}__TAX__${TAX_VERSION}/index.html"
	TAX_PACKAGES="./03__TAX__${TAX_VERSION}__packages/"
	TAX_CSV_ALL="./03__${APP_GROUP}__TAX__${TAX_VERSION}/AllIssues.csv"
	TAX_LOG="./03__${APP_GROUP}__TAX__${TAX_VERSION}.log"

	WAMT_URL="./04__WAMT__${WAMT_VERSION}/"
	WAMT_LOG="./04__WAMT__${WAMT_VERSION}.log"

	ODC_URL="./05__${APP_GROUP}__OWASP_DC__${OWASP_DC_VERSION}/"
	ODC_LOG="./05__${APP_GROUP}__OWASP_DC__${OWASP_DC_VERSION}.log"

	SCANCODE_URL="./06__${APP_GROUP}__SCANCODE__${SCANCODE_VERSION_DYNAMIC}/index.html"
	SCANCODE_LOG="./06__SCANCODE__${SCANCODE_VERSION_DYNAMIC}.log"

	PMD_URL="./07__PMD__${PMD_VERSION}/"
	PMD_LOG="./07__PMD__${PMD_VERSION}.log"

	LANGUAGES_URL="./languages.html"
	LANGUAGES_LOG="./08__LINGUIST__${LINGUIST_VERSION}.log"

	FSB_URL="./09__FindSecBugs__${FSB_VERSION}/"
	FSB_LOG="./09__FindSecBugs__${FSB_VERSION}.log"

	MAI_URL="./10__MAI__${MAI_VERSION}/"
	MAI_LOG="./10__MAI__${MAI_VERSION}.log"

	CSA_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name 'csa.db' | grep -c 'CSA' || true)
	if ((CSA_REPORT > 0)); then
		export HAS_CSA_REPORT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
	else
		export HAS_CSA_REPORT=''
	fi

	export HAS_RHAMT=''
	RHAMT_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name 'index.html' | grep -c 'RHAMT' || true)
	if ((RHAMT_REPORT > 0)); then
		export HAS_RHAMT_REPORT=TRUE
		HAS_RHAMT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
	else
		export HAS_RHAMT_REPORT=''
	fi

	RHAMT_PACKAGES_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name '_all.packages' | grep -c 'RHAMT__.*__packages' || true)
	if ((RHAMT_PACKAGES_REPORT > 0)); then
		export HAS_RHAMT_PACKAGES_REPORT=TRUE
		if [[ "${HAS_RHAMT}" == '' ]]; then
			TOOLS_COUNT=$((TOOLS_COUNT + 1))
		fi
		#HAS_RHAMT=TRUE
	else
		export HAS_RHAMT_PACKAGES_REPORT=''
	fi

	export HAS_TAX=''
	TAX_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name 'index.html' | grep -c 'TAX' || true)
	if ((TAX_REPORT > 0)); then
		export HAS_TAX_REPORT=TRUE
		HAS_TAX=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
	else
		export HAS_TAX=''
	fi

	TAX_PACKAGES_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name '_all.packages' | grep -c 'TAX__.*__packages' || true)
	if ((TAX_PACKAGES_REPORT > 0)); then
		export HAS_TAX_PACKAGES_REPORT=TRUE
		if [[ "${HAS_TAX}" == '' ]]; then
			TOOLS_COUNT=$((TOOLS_COUNT + 1))
		fi
		#HAS_TAX=TRUE
	else
		export HAS_TAX_PACKAGES_REPORT=''
	fi

	WAMT_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name '*__*.html' | grep -c 'WAMT' || true)
	if ((WAMT_REPORT > 0)); then
		export HAS_WAMT_REPORT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
	else
		export HAS_WAMT_REPORT=''
	fi

	SCANCODE_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name 'index.html' | grep -c 'SCANCODE' || true)
	if ((SCANCODE_REPORT > 0)); then
		export HAS_SCANCODE_REPORT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
	else
		export HAS_SCANCODE_REPORT=''
	fi

	export HAS_QUALITY_REPORT=''
	PMD_REPORT=$(find "${REPORTS_DIR}" -maxdepth 3 -mindepth 3 -type f -name '*__*' | grep -c 'PMD' || true)
	if ((PMD_REPORT > 0)); then
		export HAS_PMD_REPORT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
		HAS_QUALITY_REPORT=TRUE
	else
		export HAS_PMD_REPORT=''
	fi

	LANGUAGES_REPORT=$(find "${REPORTS_DIR}" -maxdepth 1 -mindepth 1 -type d | grep -c '__LINGUIST__' || true)
	if ((LANGUAGES_REPORT > 0)); then
		export HAS_LANGUAGES_REPORT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 2))
	else
		export HAS_LANGUAGES_REPORT=''
	fi

	export HAS_SECURITY_REPORT=''
	ODC_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name '*_dc_report.html' | grep -c 'OWASP_DC' || true)
	if ((ODC_REPORT > 0)); then
		export HAS_ODC_REPORT=TRUE
		HAS_SECURITY_REPORT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
	else
		export HAS_ODC_REPORT=''
	fi

	FSB_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name '*__*.html' | grep -c 'FindSecBugs' || true)
	if ((FSB_REPORT > 0)); then
		export HAS_FSB_REPORT=TRUE
		HAS_SECURITY_REPORT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
	else
		export HAS_FSB_REPORT=''
	fi

	if [[ "${HAS_TAX}" == TRUE || "${HAS_RHAMT}" == TRUE || "${HAS_WAMT_REPORT}" == TRUE || "${HAS_CSA_REPORT}" == TRUE ]]; then
		export HAS_CLOUD_REPORT=TRUE
	else
		export HAS_CLOUD_REPORT=''
	fi

	if [[ "${HAS_TAX}" == TRUE || "${HAS_TAX_PACKAGES_REPORT}" == TRUE ]]; then
		export HAS_TAX_OR_PACKAGES_REPORT=TRUE
	else
		export HAS_TAX_OR_PACKAGES_REPORT=''
	fi

	if [[ "${HAS_RHAMT}" == TRUE || "${HAS_RHAMT_PACKAGES_REPORT}" == TRUE ]]; then
		export HAS_RHAMT_OR_PACKAGES_REPORT=TRUE
	else
		export HAS_RHAMT_OR_PACKAGES_REPORT=''
	fi

	MAI_REPORT=$(find "${REPORTS_DIR}" -maxdepth 2 -mindepth 2 -type f -name 'mai_*.html' | grep -c 'MAI' || true)
	if ((MAI_REPORT > 0)); then
		export HAS_MAI_REPORT=TRUE
		TOOLS_COUNT=$((TOOLS_COUNT + 1))
	else
		export HAS_MAI_REPORT=''
	fi

	export HAS_LICENSE_REPORT=''
}

function dropdown() {
	PAGE="${1}"
	DROPDOWN_ITEMS=""
	if [[ -n "${TARGET_GROUP}" ]]; then
		DROPDOWN_ITEMS+="<a class=\"dropdown-item active\" href=\"#\">${TARGET_GROUP}</a>"
	else
		while read -r DIR; do
			GROUP=$(basename "${DIR}")
			if [[ "${GROUP}" == "${APP_GROUP}" ]]; then
				DROPDOWN_ITEMS+="<a class=\"dropdown-item active\" href=\"#\">${GROUP}</a>"
			elif [[ "${GROUP}" == "${FIST_GROUP}" ]]; then
				DROPDOWN_ITEMS+="<a class=\"dropdown-item\" href=\"${REPORTS_DIR}/${PAGE}.html\">${GROUP}</a>"
			else
				DROPDOWN_ITEMS+="<a class=\"dropdown-item\" href=\"${REPORTS_DIR}/${PAGE}_${GROUP}.html\">${GROUP}</a>"
			fi
		done < <(find "${APP_DIR_IN}" -maxdepth 1 -mindepth 1 -type d | sort)
	fi
}

function add_language_column() {
	APP_GROUP=${1}
	TMP_CSV=${2}
	export LANG_CSV="${REPORTS_DIR}/list__${APP_GROUP}__all_apps.csv"
	# Add the language column
	{
		echo "Applications${SEPARATOR}Language"
		cat "${LANG_CSV}"
	} >"${TMP_CSV}.lang"

	paste -d "${SEPARATOR}" "${TMP_CSV}.lang" <(cut -d "${SEPARATOR}" -f2- "${TMP_CSV}") >"${TMP_CSV}.tmp.tmp"

	# Remove spaces and tabs, excepted in the header.
	head -n 1 "${TMP_CSV}.tmp.tmp" | tr -d "\t" >"${TMP_CSV}.tmp"
	sed '1d' "${TMP_CSV}.tmp.tmp" | tr -d " \t" >>"${TMP_CSV}.tmp"

	mv "${TMP_CSV}.tmp" "${TMP_CSV}"
	rm -f "${TMP_CSV}.lang" "${TMP_CSV}.tmp.tmp"
}

function generate_cloud_csv() {
	TMP_CSV=${1}
	APP_GROUP=${2}

	rm -f "${TMP_CSV}"

	#export LANG_CSV="${REPORTS_DIR}/list__${APP_GROUP}__all_apps.csv"
	export CSA_CSV="${REPORTS_DIR}/02__CSA__${CSA_VERSION}__results_extracted.csv"
	export TAX_CSV="${REPORTS_DIR}/03__${APP_GROUP}__TAX__${TAX_VERSION}__results_extracted.csv"
	export RHAMT_CSV="${REPORTS_DIR}/03__${APP_GROUP}__RHAMT_CSV__${RHAMT_VERSION}__results_extracted.csv"
	export WAMT_CSV="${REPORTS_DIR}/04__WAMT__${WAMT_VERSION}/${APP_GROUP}___results_extracted.csv"

	export WINDUP_CSV=''
	if [[ -f "${TAX_CSV}" ]]; then
		WINDUP_CSV="${TAX_CSV}"
	elif [[ -f "${RHAMT_CSV}" ]]; then
		WINDUP_CSV="${RHAMT_CSV}"
	fi

	# Debug info to compare the result counts
	#echo "LANG_CSV     - $(cat $LANG_CSV | wc -l |  tr -d ' \t') entries - $LANG_CSV"
	#echo "CSA_CSV      - $(cat $CSA_CSV | wc -l |  tr -d ' \t') entries - $CSA_CSV"
	#echo "WINDUP_CSV   - $(cat $WINDUP_CSV | wc -l |  tr -d ' \t')-1 entries - $WINDUP_CSV"
	#echo "WAMT_CSV     - $(cat $WAMT_CSV | wc -l |  tr -d ' \t')-1 entries - $WAMT_CSV"

	if [[ -f "${WINDUP_CSV}" ]]; then
		if [[ -f "${CSA_CSV}" ]]; then
			echo "Applications${SEPARATOR}CSA tech score" >"${CSA_CSV}.tmp"
			grep "${APP_GROUP}" "${CSA_CSV}" | cut -d "${SEPARATOR}" -f2,4 | sort | uniq >>"${CSA_CSV}.tmp"

			# Merge Windup and CSA results
			paste -d "${SEPARATOR}" "${CSA_CSV}.tmp" <(cut -d "${SEPARATOR}" -f2- "${WINDUP_CSV}") | tr -d '\t' >>"${TMP_CSV}"

			rm -f "${CSA_CSV}.tmp"
		else
			cat "${WINDUP_CSV}" >>"${TMP_CSV}"
		fi
	elif [[ -f "${CSA_CSV}" ]]; then
		echo "Applications${SEPARATOR}CSA tech score" >"${TMP_CSV}"
		grep "${APP_GROUP}" "${CSA_CSV}" | cut -d "${SEPARATOR}" -f2,4 | sort | uniq >>"${TMP_CSV}"
	fi

	if [[ -f "${WAMT_CSV}" ]]; then
		if [ -s "${TMP_CSV}" ]; then
			paste -d "${SEPARATOR}" "${TMP_CSV}" <(cut -d "${SEPARATOR}" -f2- "${WAMT_CSV}") >"${WAMT_CSV}.tmp"
			mv "${WAMT_CSV}.tmp" "${TMP_CSV}"
		else
			cat "${WAMT_CSV}" >>"${TMP_CSV}"
		fi
	fi

	add_language_column "${APP_GROUP}" "${TMP_CSV}"
}

function generate_security_csv() {

	TMP_CSV=${1}
	APP_GROUP=${2}

	rm -f "${TMP_CSV}"

	#export LANG_CSV="${REPORTS_DIR}/list__${APP_GROUP}__all_apps.csv"
	export ODC_CSV_FILE="${REPORTS_DIR}/05__${APP_GROUP}__OWASP_DC__${OWASP_DC_VERSION}/${APP_GROUP}___results_extracted.csv"
	export FSB_CSV_FILE="${REPORTS_DIR}/09__FindSecBugs__${FSB_VERSION}/${APP_GROUP}___results_extracted.csv"
	export FSB_CSV="./09__FindSecBugs__${FSB_VERSION}/${APP_GROUP}___results_extracted.csv"

	# Debug info to compare the result counts
	#echo "LANG_CSV     - $(cat $LANG_CSV | wc -l |  tr -d ' \t') entries - $LANG_CSV"
	#echo "ODC_CSV_FILE      - $(cat $ODC_CSV_FILE | wc -l |  tr -d ' \t') entries - $ODC_CSV_FILE"
	#echo "FSB_CSV_FILE      - $(cat $FSB_CSV_FILE | wc -l |  tr -d ' \t') entries - $FSB_CSV_FILE"

	if [[ -f "${ODC_CSV_FILE}" ]]; then
		if [[ -f "${FSB_CSV_FILE}" ]]; then
			paste -d "${SEPARATOR}" "${ODC_CSV_FILE}" <(cut -d "${SEPARATOR}" -f2- "${FSB_CSV_FILE}") >>"${TMP_CSV}"
		else
			cat "${ODC_CSV_FILE}" >>"${TMP_CSV}"
		fi
	else
		cat "${FSB_CSV_FILE}" >>"${TMP_CSV}"
	fi

	add_language_column "${APP_GROUP}" "${TMP_CSV}"
}

function generate_quality_csv() {
	TMP_CSV=${1}
	APP_GROUP=${2}
	export PMD_CSV="${REPORTS_DIR}/07__PMD__${PMD_VERSION}/${APP_GROUP}___results_extracted.csv"
	if [[ -f "${PMD_CSV}" ]]; then
		cat "${PMD_CSV}" >"${TMP_CSV}"
	else
		log_console_error "PMD file missing: ${PMD_CSV}"
	fi
}

# Generate the index and security reports
function generate_reports() {

	export GROUP_POSTFIX DROPDOWN_ITEMS

	APP_GROUP=$(basename "${1}")
	GROUP_POSTFIX=''
	if [[ "${IS_FIRST_GROUP}" == "true" ]]; then
		IS_FIRST_GROUP="false"
		FIST_GROUP="${APP_GROUP}"
	else
		GROUP_POSTFIX="_${APP_GROUP}"
	fi

	LINK_REPORT="${REPORTS_DIR}/index${GROUP_POSTFIX}.html"
	CLOUD_REPORT="${REPORTS_DIR}/cloud${GROUP_POSTFIX}.html"
	SECURITY_REPORT="${REPORTS_DIR}/security${GROUP_POSTFIX}.html"
	QUALITY_REPORT="${REPORTS_DIR}/quality${GROUP_POSTFIX}.html"

	# Export all variables for the reports
	export_vars "${1}"

	# Generate overview report (index)
	dropdown index
	${MUSTACHE} "${TEMPLATE_DIR}/index.mo" >"${LINK_REPORT}"
	log_console_success "Open this file for reviewing all generated reports: ${LINK_REPORT}"

	# Generate cloud report
	if [[ "${HAS_CLOUD_REPORT}" == TRUE ]]; then

		dropdown cloud
		# Generate CSV file with all results
		generate_cloud_csv "${CLOUD_TMP_CSV}" "${APP_GROUP}"

		RESULT_REPORT_MAP="${REPORTS_DIR}/03__${APP_GROUP}__report_map.js"

		# Generate cloud HTML file
		{
			${MUSTACHE} "${TEMPLATE_DIR}/cloud_01.mo"
			echo 'const longText = `'\\
			cat "${CLOUD_TMP_CSV}"
			echo '`;'
			[[ -f "${RESULT_REPORT_MAP}" ]] && cat "${RESULT_REPORT_MAP}"
			${MUSTACHE} "${TEMPLATE_DIR}/cloud_02.mo"
		} >"${CLOUD_REPORT}"

		#rm -f "${RESULT_REPORT_MAP}"
		log_console_info "Open this file for reviewing all generated reports: ${CLOUD_REPORT}"
	fi

	# Generate security reports
	if [[ "${HAS_SECURITY_REPORT}" == TRUE ]]; then

		dropdown security
		# Generate CSV file with all results
		generate_security_csv "${SECURITY_TMP_CSV}" "${APP_GROUP}"

		# Generate security HTML file
		{
			${MUSTACHE} "${TEMPLATE_DIR}/security_01.mo"
			echo 'const longText = `'\\
			cat "${SECURITY_TMP_CSV}"
			echo '`;'
			${MUSTACHE} "${TEMPLATE_DIR}/security_02.mo"
		} >"${SECURITY_REPORT}"

		log_console_info "Open this file for reviewing all generated reports: ${SECURITY_REPORT}"
	fi

	# Generate quality reports
	if [[ "${HAS_QUALITY_REPORT}" == TRUE ]]; then

		dropdown quality
		# Generate CSV file with all results
		generate_quality_csv "${QUALITY_TMP_CSV}" "${APP_GROUP}"

		if [[ -f "${QUALITY_TMP_CSV}" ]]; then
			# Generate security HTML file
			{
				${MUSTACHE} "${TEMPLATE_DIR}/quality_01.mo"
				echo 'const longText = `'\\
				cat "${QUALITY_TMP_CSV}"
				echo '`;'
				${MUSTACHE} "${TEMPLATE_DIR}/quality_02.mo"
			} >"${QUALITY_REPORT}"
			log_console_info "Open this file for reviewing all generated reports: ${QUALITY_REPORT}"
		else
			log_console_error "Quality file missing: ${QUALITY_TMP_CSV}"
		fi
	fi

	# Merging all results in one summary CSV file (${SUMMARY_CSV})
	rm -f "${SUMMARY_CSV}"
	touch "${SUMMARY_CSV}"

	if [[ -f "${CLOUD_TMP_CSV}" ]]; then
		cp -f "${CLOUD_TMP_CSV}" "${SUMMARY_CSV}"
	fi

	if [[ -f ${SECURITY_TMP_CSV} ]]; then
		if [[ -f "${SUMMARY_CSV}" ]]; then
			paste -d "${SEPARATOR}" "${SUMMARY_CSV}" <(cut -d "${SEPARATOR}" -f3- "${SECURITY_TMP_CSV}") >>"${SUMMARY_CSV}.tmp"
			mv "${SUMMARY_CSV}.tmp" "${SUMMARY_CSV}"
		else
			cp -f "${SECURITY_TMP_CSV}" "${SUMMARY_CSV}"
		fi
	fi

	if [[ -f ${QUALITY_TMP_CSV} ]]; then
		if [[ -f "${SUMMARY_CSV}" ]]; then
			paste -d "${SEPARATOR}" "${SUMMARY_CSV}" <(cut -d "${SEPARATOR}" -f3- "${QUALITY_TMP_CSV}") >>"${SUMMARY_CSV}.tmp"
			mv "${SUMMARY_CSV}.tmp" "${SUMMARY_CSV}"
		else
			cp -f "${QUALITY_TMP_CSV}" "${SUMMARY_CSV}"
		fi
	fi

	rm -f "${CLOUD_TMP_CSV}" "${SECURITY_TMP_CSV}" "${QUALITY_TMP_CSV}"

	cp "${SUMMARY_CSV}" "${SUMMARY_CSV_FULL_NAME}"
}

# Generate HTML file vizualising the CLOC and Linguist results
function generate_language_report() {
	export APP_DATE LANGUAGES_REPORT REPORT_TIMESTAMP HEIGHT LINGUIST_CSV CLOC_CSV LANGUAGES_LOG
	CLOC_CSV="./08__LOC__CLOC__results_extracted.csv"
	LINGUIST_CSV="./08__LOC__LINGUIST__results_extracted.csv"
	OUTPUT_CLOC_FILE="${REPORTS_DIR}/08__LOC__CLOC__results_generated.txt"
	OUTPUT_LINGUIST_FILE="${REPORTS_DIR}/08__LOC__LINGUIST__results_generated.txt"
	LANGUAGES_LOG="./08__LINGUIST__${LINGUIST_VERSION}.log"

	if [[ -f "${OUTPUT_LINGUIST_FILE}" && -f "${OUTPUT_CLOC_FILE}" ]]; then

		APP_DATE="$(echo "${TIMESTAMP}" | cut -d'_' -f 1-3 | sed 's/_/./g') at $(echo "${TIMESTAMP}" | cut -d'_' -f 5-7 | sed 's/_/:/g')"

		LANGUAGES_REPORT="${REPORTS_DIR}/languages.html"
		REPORT_TIMESTAMP=$(date +%Y.%m.%d\ at\ %H:%M:%S)
		# HEIGHT: LINES x23 + 40
		APPS=$(uniq <"${OUTPUT_LINGUIST_FILE}" | wc -l)
		CALCULATED_HEIGHT=$(((APPS - 2) * 23 + 40))
		HEIGHT=$((450 > CALCULATED_HEIGHT ? 450 : CALCULATED_HEIGHT))

		# Header
		${MUSTACHE} "${TEMPLATE_DIR}/languages_01.mo" >"${LANGUAGES_REPORT}"
		# Append prepared data
		{
			echo 'const longTextCloc = `'\\
			cat "${OUTPUT_CLOC_FILE}"
			echo '`;' >>"${LANGUAGES_REPORT}"
			echo 'const longTextLinguist = `'\\
			cat "${OUTPUT_LINGUIST_FILE}"
			echo '`;'
		} >>"${LANGUAGES_REPORT}"
		# Footer
		${MUSTACHE} "${TEMPLATE_DIR}/languages_02.mo" >>"${LANGUAGES_REPORT}"
		log_console_info "Open this file for reviewing all generated reports: ${LANGUAGES_REPORT}"

	fi
}

# Generate HTML file linking all reports
function main() {
	mkdir -p "${APP_DIR_IN}"
	mkdir -p "${REPORTS_DIR}"
	cp -Rfp "${TEMPLATE_DIR}/static" "${REPORTS_DIR}/."

	export APP_DATE LINK_REPORT CSA_LOG REPORT_TIMESTAMP
	APP_DATE="$(echo "${TIMESTAMP}" | cut -d'_' -f 1-3 | sed 's/_/./g') at $(echo "${TIMESTAMP}" | cut -d'_' -f 5-7 | sed 's/_/:/g')"
	CSA_LOG="./02__CSA__${CSA_VERSION}.log"
	REPORT_TIMESTAMP=$(date +%Y.%m.%d\ at\ %H:%M:%S)

	for_each_group generate_reports

	generate_language_report

	log_console_info "Results: ${SUMMARY_CSV}"
}

main
