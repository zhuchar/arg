#!/bin/bash

DOCKER_BIN=/usr/local/bin/docker
DOCKER_SOCKET=/var/run/docker.sock
APPS_DIR=$HOME/app-report-gen/apps
REPORTS_DIR=$HOME/app-report-gen/reports

docker run -it --rm \
        -v $DOCKER_BIN:/usr/bin/docker \
        -v $DOCKER_SOCKET:/var/run/docker.sock \
        -v $APPS_DIR:/app-report-gen/apps \
        -v $REPORTS_DIR:/app-report-gen/reports \
        app-report-gen

	# In case you want to pass different arguments just add them after the image name
	# For example:
	# app-report-gen -a 
