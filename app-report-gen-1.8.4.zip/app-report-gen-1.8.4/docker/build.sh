#!/bin/bash

SCRIPT_DIR=$(dirname "$BASH_SOURCE")

if [ "$SCRIPT_DIR" != "." ]; then 
	echo "Please execute from the script directory"
	exit -1
fi

(cd .. && docker build -t app-report-gen -f docker/Dockerfile .)
