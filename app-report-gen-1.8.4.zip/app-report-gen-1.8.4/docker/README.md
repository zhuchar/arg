# How To Use Docker for ARG

In order to use Docker for running App Report Generator you need to:
1. Download Docker Image
2. Load Docker Image
3. Create Docker Container (docker-inside-docker enabled)

## 1. Download Docker Image

```
curl -so https://github.com/pivotal/app-report-gen/releases/download/v1.8.2/app-report-gen.img 
```

## 2. Load Docker Image

```
docker image load -i app-report-gen.img
```

## 3. Create Docker Container (docker-inside-docker enabled)

```
./run.sh
```

Pre-requisites:
* Adjust script variables accordingly (inside run.sh) before running the script

Disclaimer:
* Docker Image run all tools except ScanCode (takes forever) 
* App-Report-Gen options: -pxwoflmi
* Scripts tested on a Mac OS X 10.15.7

## Build Docker Image and Generate Image File

In case you want to build the docker image, you could use the following script:
```
./build.sh
docker image save app-report-gen | gzip > app-report-gen.img
```

Pre-requisites:
* Download dists before (see: [download_dists.sh](../util/01__setup/download_dists.sh)) or work with an ARG release version


